# BLS12-381.mo

BLS12-381 elliptic-curve and pairing operations for Motoko, including the operations required by Ethereum's EIP-2537 precompile interface.

> [!WARNING]
> This package has not received an independent cryptographic security audit. Review it carefully before using it to protect production assets or consensus-critical state.

## Installation

```sh
mops add bls12-381
```

```motoko
import BLS "mo:bls12-381";
```

The public API is exported by `src/lib.mo`. It includes field-tower arithmetic, G1 and G2 point operations, encoding and decoding, hash-to-curve helpers, multi-scalar multiplication, and pairing checks.

The package targets moc 1.8.2 and uses `mo:core` exclusively; it has no `mo:base` dependency.

## Prepared G2

Use `prepare_g2(q)` once when a validated G2 point is reused, then call
`pairing_check_prepared([(p, preparedQ), ...])`. The combined loop still shares
Fp12 squaring and performs one final exponentiation. G1 inputs may change between calls.
The ordinary `pairing_check` API remains available for one-off inputs.

```motoko
// These generators are known valid subgroup points. Validate external keys first.
let prepared = BLS.prepare_g2(BLS.G2_GEN);
assert BLS.pairing_check_prepared([
  (BLS.G1_GEN, prepared),
  (BLS.g1_neg(BLS.G1_GEN), prepared),
]);
```

Preparation is useful only when reused: preparing both G2 inputs on every call
costs approximately the same as the ordinary pairing check.

These are low-level operations with the same valid-point preconditions as `pairing`:
decode and validate on-curve/subgroup membership before preparation, and apply your
protocol's infinity rules. Prepared records are trusted derived data, not an input
encoding; do not accept arbitrary coefficient arrays from untrusted callers.
Cache by the actual validated key and replace the cache when that key changes.
Rebuild prepared caches after a library upgrade; the coefficient layout is internal.

`g1_from_affine` and `g2_from_affine` require canonical components below `P`,
accept the canonical all-zero infinity encoding, and check the curve equation.
They do not check subgroup membership. Reduce integers explicitly before calling
if modular reduction is intended.

## Verification

```sh
mops install
dfx build --check bls_test
npm ci
npm test -- --runInBand
mops bench
```

The randomized pairing/MSM suite is computationally expensive and should run in release CI with a generous timeout. Saved `.bench/` results provide the checked-in pre-Core performance baseline.

## Provenance and licensing

The implementation was developed for ICDevs and is licensed under Apache-2.0. Constants and algorithm structure were checked against `@noble/curves`; its MIT attribution is recorded in [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md). Ethereum EIP-2537 defines the externally compatible operation set.

## Release policy

Releases require a clean dependency installation, `dfx build --check bls_test`, the deterministic and randomized Noble-reference suites, and an EVM downstream build/test checkpoint.

## Performance measurements

See [the staged feedback experiment](bench/feedback/README.md) for measurements and
reproduction commands. The buffer prototype was not included in this release.
