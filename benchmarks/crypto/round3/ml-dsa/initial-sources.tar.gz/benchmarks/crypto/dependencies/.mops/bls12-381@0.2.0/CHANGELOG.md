# Changelog

## 0.2.0 — 2026-09-24

- Add `prepare_g2`, `multi_miller_loop_prepared`, and `pairing_check_prepared` to reuse immutable G2 Miller-loop coefficients while retaining shared squaring and one final exponentiation.
- Reject coordinates or Fp2 components greater than or equal to `P` in `g1_from_affine` and `g2_from_affine`, before infinity and curve checks. This prevents accepted G2 points from trapping in later arithmetic. Callers intending modular reduction must now reduce explicitly.
- Add affine-boundary and prepared-pairing regression tests and reproducible benchmarks. Reused preparation reduced instructions by approximately 18% and temporary allocation by 17% in the representative two-pair benchmark; complete signature verification was not measured.

## 0.1.0 — 2026-09-24

- Initial ICDevs release of BLS12-381 field, curve, hash-to-curve, encoding, multi-scalar multiplication, and pairing operations.
- EIP-2537-compatible test-canister interface.
- Deterministic and randomized correctness comparisons against `@noble/curves`.
- Montgomery-field and pairing performance benchmarks.
- Migrated the implementation, test canister, and benchmarks from `mo:base` to `mo:core` on moc 1.8.2.
- Replaced temporary mutable buffers with fixed arrays or `PureList` accumulators; the post-migration benchmark is neutral overall and improves two-pair Miller-loop instructions and garbage collection by approximately 0.03% and 0.05%, respectively.
