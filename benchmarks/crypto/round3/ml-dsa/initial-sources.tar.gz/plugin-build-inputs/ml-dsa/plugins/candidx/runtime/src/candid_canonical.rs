//! Internal used-shape support for compiler-generated canonical serialization.
//! Payload traversal, sizing, and emission belong to generated Wasm code.

use alloc::boxed::Box;
use alloc::vec::Vec;
use core::mem::{align_of, size_of, take};

const MAX_DEPTH: usize = 256;
const MAX_ITEMS: usize = 2_000_000;
const MAX_TYPES: usize = 1024;
const MAX_BYTES: usize = 32 * 1024 * 1024;
const MAX_SCRATCH: usize = 256 * 1024 * 1024;
const MISSING: i64 = i64::MIN;

type Checked<T> = core::result::Result<T, Error>;

// Generator-only errors reserve the gaps in these shared status numbers.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u8)]
enum Error {
    CollectionLengthLimit = 0,
    FieldIdRange = 2,
    HeaderPointerRange = 4,
    HeaderSizeChanged = 5,
    IncompatibleValueShapes = 6,
    IndexRange = 7,
    InvalidFieldBuilderOpcode = 9,
    InvalidFieldShape = 10,
    InvalidShapeUnion = 11,
    InvalidUnaryShape = 12,
    MissingDerivedVariant = 13,
    MissingFieldBuilder = 14,
    MissingFieldShape = 15,
    MissingShapeJoiner = 16,
    MissingUnaryShape = 17,
    MissingVariantShape = 18,
    NullShapeContext = 19,
    OutputByteLimit = 21,
    OutputTypeTableLimit = 22,
    RootIndexRange = 23,
    ScratchAllocationFailed = 24,
    ScratchByteLimit = 25,
    ShapeContextIsFinalized = 26,
    ShapeReferenceRange = 27,
    TypeNestingLimit = 29,
    UnfinishedFieldBuilder = 31,
    UnfinishedShapeJoiner = 32,
    UnorderedFieldIds = 33,
    UnsupportedCompoundShape = 34,
    UnsupportedShapeReference = 35,
    ValueNestingLimit = 38,
    ValueTraversalLimit = 39,
}

// Reserved status values cannot alias primitive opcodes, node IDs or MISSING.
const ERROR_BASE: i64 = -1000;
#[cfg(test)]
const ERRORS: &[&str] = &[
    "collection length limit",
    "empty has no values",
    "field ID range",
    "function and service values are excluded",
    "header pointer range",
    "header size changed",
    "incompatible value shapes",
    "index range",
    "integer length limit",
    "invalid field builder opcode",
    "invalid field shape",
    "invalid shape union",
    "invalid unary shape",
    "missing derived variant",
    "missing field builder",
    "missing field shape",
    "missing shape joiner",
    "missing unary shape",
    "missing variant shape",
    "null shape context",
    "output buffer not filled",
    "output byte limit",
    "output type-table limit",
    "root index range",
    "scratch allocation failed",
    "scratch byte limit",
    "shape context is finalized",
    "shape reference range",
    "source type field ids must strictly increase",
    "type nesting limit",
    "unexpected variant",
    "unfinished field builder",
    "unfinished shape joiner",
    "unordered field IDs",
    "unsupported compound shape",
    "unsupported shape reference",
    "unsupported source type",
    "unsupported source value",
    "value nesting limit",
    "value traversal limit",
];
fn status(error: Error) -> i64 {
    ERROR_BASE + error as i64
}

// The ephemeral allocator backs allocations with a three-word Blob header.
// Include its alignment padding and heap-word rounding, as well as the entire
// new allocation on every growth: old buffers remain garbage until GC.
fn allocation_size<T>(count: usize) -> Checked<usize> {
    let word = size_of::<usize>();
    let alignment = align_of::<T>().max(word);
    count
        .checked_mul(size_of::<T>())
        .and_then(|n| n.checked_add(3 * word + alignment - 1))
        .ok_or(Error::ScratchByteLimit)
}
struct Scratch {
    used: usize,
    limit: usize,
}
impl Scratch {
    fn charge<T>(&mut self, count: usize) -> Checked<()> {
        self.used = self
            .used
            .checked_add(allocation_size::<T>(count)?)
            .filter(|used| *used <= self.limit)
            .ok_or(Error::ScratchByteLimit)?;

        Ok(())
    }

    fn reserve<T>(&mut self, values: &mut Vec<T>, required: usize) -> Checked<()> {
        if values.capacity() >= required {
            return Ok(());
        }
        let capacity = required.max(values.capacity().saturating_mul(2));
        self.charge::<T>(capacity)?;
        values
            .try_reserve_exact(capacity - values.len())
            .map_err(|_| Error::ScratchAllocationFailed)?;

        Ok(())
    }

    fn push<T>(&mut self, values: &mut Vec<T>, value: T) -> Checked<()> {
        let required = values.len().checked_add(1).ok_or(Error::ScratchByteLimit)?;
        self.reserve(values, required)?;
        values.push(value);

        Ok(())
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct Field {
    id: u32,
    child: i64,
}
struct Node {
    op: i64,
    child: i64,
    fields: Vec<Field>,
    hash: u64,
    // Compound levels only: an unused empty-vector scalar element does not
    // consume a value visit. Source value depths are checked by `visit`.
    height: usize,
}
struct Builder {
    op: i64,
    fields: Vec<Field>,
    height: usize,
    previous: i64,
}
struct Joiner {
    // Each occupied level represents a contiguous block twice the size of
    // the previous level. Carrying equal-sized blocks prevents a growing
    // variant union from retaining a quadratic number of field entries.
    levels: Vec<i64>,
    last: i64,
}
// Unary keys use a negative opcode; record-union keys use nonnegative node
// IDs. Exact key checks separate both namespaces, including cache collisions.
#[derive(Clone, Copy)]
struct ShapeMemo {
    a: i64,
    b: i64,
    result: i64,
}
const SHAPE_MEMOS: usize = 32;
struct Context {
    scratch: Scratch,
    visits: usize,
    nodes: Vec<Node>,
    slots: Vec<usize>,
    builders: Vec<Builder>,
    building: usize,
    joins: Vec<Vec<Field>>,
    shape_memos: Option<Box<[ShapeMemo; SHAPE_MEMOS]>>,
    joiners: Vec<Joiner>,
    joining: usize,
    roots: Vec<i64>,
    wire_ids: Vec<i64>,
    table: Vec<i64>,
    header_size: Option<usize>,
}

fn primitive(t: i64) -> bool {
    (-17..=-1).contains(&t) || t == -24
}
fn index(value: u64) -> Checked<usize> {
    usize::try_from(value).map_err(|_| Error::IndexRange)
}
fn label(value: u64) -> Checked<u32> {
    u32::try_from(value).map_err(|_| Error::FieldIdRange)
}
// MurmurHash64A word rounds and final avalanche (Austin Appleby, public
// domain). Shape keys are whole words, so no byte-buffer or tail is needed.
// https://github.com/aappleby/smhasher/blob/master/src/MurmurHash2.cpp
const HASH_MULTIPLIER: u64 = 0xc6a4_a793_5bd1_e995;
fn mix(hash: &mut u64, word: u64) {
    let word = word.wrapping_mul(HASH_MULTIPLIER);
    let word = (word ^ (word >> 47)).wrapping_mul(HASH_MULTIPLIER);
    *hash = (*hash ^ word).wrapping_mul(HASH_MULTIPLIER);
}
fn shape_hash(op: i64, child: i64, fields: &[Field]) -> u64 {
    let bytes = (3 + 2 * fields.len()) as u64 * 8;
    let mut hash = bytes.wrapping_mul(HASH_MULTIPLIER);
    mix(&mut hash, op as u64);
    mix(&mut hash, child as u64);
    mix(&mut hash, fields.len() as u64);
    for field in fields {
        mix(&mut hash, u64::from(field.id));
        mix(&mut hash, field.child as u64);
    }
    hash ^= hash >> 47;
    hash = hash.wrapping_mul(HASH_MULTIPLIER);
    hash ^ (hash >> 47)
}

impl Context {
    fn new() -> Self {
        let mut scratch = Scratch {
            used: 0,
            limit: MAX_SCRATCH,
        };
        scratch
            .charge::<Self>(1)
            .expect("context fits scratch limit");
        Self {
            scratch,
            visits: 0,
            nodes: Vec::new(),
            slots: Vec::new(),
            builders: Vec::new(),
            building: 0,
            joins: Vec::new(),
            shape_memos: None,
            joiners: Vec::new(),
            joining: 0,
            roots: Vec::new(),
            wire_ids: Vec::new(),
            table: Vec::new(),
            header_size: None,
        }
    }
    #[inline(always)]
    fn open(&self) -> Checked<()> {
        if self.header_size.is_some() {
            return Err(Error::ShapeContextIsFinalized);
        }

        Ok(())
    }

    #[inline(always)]
    fn check(&self, t: i64) -> Checked<()> {
        if t < 0 {
            if !primitive(t) {
                return Err(Error::UnsupportedShapeReference);
            }
        } else if t as u64 >= self.nodes.len() as u64 {
            return Err(Error::ShapeReferenceRange);
        }

        Ok(())
    }

    #[inline(always)]
    fn op(&self, t: i64) -> i64 {
        if t < 0 {
            t
        } else {
            self.nodes[t as usize].op
        }
    }
    #[inline(always)]
    fn height(&self, t: i64) -> usize {
        if t < 0 {
            0
        } else {
            self.nodes[t as usize].height
        }
    }
    #[inline(always)]
    fn visit(&mut self, depth: u64, count: u64) -> Checked<()> {
        if depth > MAX_DEPTH as u64 {
            return Err(Error::ValueNestingLimit);
        }
        self.visits = self
            .visits
            .checked_add(index(count)?)
            .filter(|visits| *visits <= MAX_ITEMS)
            .ok_or(Error::ValueTraversalLimit)?;

        Ok(())
    }

    fn rebuild_slots(&mut self, size: usize) -> Checked<()> {
        let mut slots = Vec::new();
        self.scratch.reserve(&mut slots, size)?;
        slots.resize(size, 0);
        for (id, node) in self.nodes.iter().enumerate() {
            let mut slot = node.hash as usize & (size - 1);
            while slots[slot] != 0 {
                slot = (slot + 1) & (size - 1);
            }
            slots[slot] = id + 1;
        }
        self.slots = slots;

        Ok(())
    }

    #[inline(always)]
    fn intern(&mut self, op: i64, child: i64, fields: &[Field]) -> Checked<i64> {
        self.open()?;
        let mut height = 1;
        match op {
            -18 | -19 => {
                if !fields.is_empty() {
                    return Err(Error::InvalidUnaryShape);
                }
                self.check(child)?;
                height += self.height(child);
            }
            -20 | -21 => {
                if child != MISSING || fields.len() > MAX_ITEMS {
                    return Err(Error::InvalidFieldShape);
                }
                let mut previous = None;
                for field in fields {
                    if previous.is_some_and(|id| id >= field.id) {
                        return Err(Error::UnorderedFieldIds);
                    }
                    previous = Some(field.id);
                    self.check(field.child)?;
                    height = height.max(self.height(field.child) + 1);
                }
            }
            _ => return Err(Error::UnsupportedCompoundShape),
        }
        self.intern_validated(op, child, fields, height)
    }

    // Callers establish valid child references, sorted field IDs and the
    // computed height while constructing the shape, in an open context.
    fn intern_validated(
        &mut self,
        op: i64,
        child: i64,
        fields: &[Field],
        height: usize,
    ) -> Checked<i64> {
        if fields.len() > MAX_ITEMS {
            return Err(Error::InvalidFieldShape);
        }
        if height > MAX_DEPTH + 1 {
            return Err(Error::TypeNestingLimit);
        }
        let hash = shape_hash(op, child, fields);
        if !self.slots.is_empty() {
            let mut slot = hash as usize & (self.slots.len() - 1);
            while self.slots[slot] != 0 {
                let id = self.slots[slot] - 1;
                let node = &self.nodes[id];
                if node.hash == hash
                    && node.op == op
                    && node.child == child
                    && node.fields == fields
                {
                    return Ok(id as i64);
                }
                slot = (slot + 1) & (self.slots.len() - 1);
            }
        }
        if self.nodes.len() + 1 > self.slots.len() / 2 {
            self.rebuild_slots(self.slots.len().saturating_mul(2).max(8))?;
        }
        let mut retained = Vec::new();
        if !fields.is_empty() {
            self.scratch.reserve(&mut retained, fields.len())?;
            retained.extend_from_slice(fields);
        }
        let id = self.nodes.len();
        self.scratch.push(
            &mut self.nodes,
            Node {
                op,
                child,
                fields: retained,
                hash,
                height,
            },
        )?;
        let mut slot = hash as usize & (self.slots.len() - 1);
        while self.slots[slot] != 0 {
            slot = (slot + 1) & (self.slots.len() - 1);
        }
        self.slots[slot] = id + 1;
        Ok(id as i64)
    }

    fn begin(&mut self, op: i64) -> Checked<()> {
        self.open()?;
        if ![-20, -21].contains(&op) {
            return Err(Error::InvalidFieldBuilderOpcode);
        }
        if self.building > MAX_DEPTH {
            return Err(Error::TypeNestingLimit);
        }
        if self.building == self.builders.len() {
            self.scratch.push(
                &mut self.builders,
                Builder {
                    op,
                    fields: Vec::new(),
                    height: 1,
                    previous: MISSING,
                },
            )?;
        }
        let builder = &mut self.builders[self.building];
        builder.op = op;
        builder.fields.clear();
        builder.height = 1;
        self.building += 1;

        Ok(())
    }

    fn field(&mut self, id: u64, child: i64) -> Checked<()> {
        self.open()?;
        self.check(child)?;
        let id = label(id)?;
        let height = self.height(child) + 1;
        let builder = self
            .builders
            .get_mut(self.building.wrapping_sub(1))
            .ok_or(Error::MissingFieldBuilder)?;
        if builder.fields.len() >= MAX_ITEMS {
            return Err(Error::CollectionLengthLimit);
        }
        if builder
            .fields
            .last()
            .is_some_and(|previous| previous.id >= id)
        {
            return Err(Error::UnorderedFieldIds);
        }
        self.scratch
            .push(&mut builder.fields, Field { id, child })?;
        builder.height = builder.height.max(height);

        Ok(())
    }

    fn end(&mut self) -> Checked<i64> {
        self.open()?;
        if self.building == 0 {
            return Err(Error::MissingFieldBuilder);
        }
        self.building -= 1;
        let builder = &mut self.builders[self.building];
        let op = builder.op;
        let height = builder.height;
        let fields = take(&mut builder.fields);
        let previous = builder.previous;
        // Repeated records at this nesting level often have the same shape.
        // Fields were checked as inserted; equality also preserves height.
        let result = if op == -20
            && previous != MISSING
            && self.nodes[previous as usize].op == op
            && self.nodes[previous as usize].fields == fields
        {
            previous
        } else {
            self.intern_validated(op, MISSING, &fields, height)?
        };
        let builder = &mut self.builders[self.building];
        builder.fields = fields;
        builder.previous = result;
        Ok(result)
    }

    fn variant(&mut self, id: u64, child: i64) -> Checked<i64> {
        self.open()?;
        self.check(child)?;
        let field = Field {
            id: label(id)?,
            child,
        };
        self.intern_validated(-21, MISSING, &[field], self.height(child) + 1)
    }

    fn unary(&mut self, op: i64, child: i64) -> Checked<i64> {
        // Options commonly repeat. Cache vectors after the table exists,
        // avoiding an allocation for a lone outer vector or binary value.
        if op != -18 && (op != -19 || self.shape_memos.is_none()) {
            return Ok(self.intern(op, child, &[])?);
        }
        self.open()?;
        let key = ((op as u64).rotate_left(7) ^ child as u64).wrapping_mul(0x9e37_79b1_85eb_ca87);
        let slot = (key >> 32) as usize & (SHAPE_MEMOS - 1);
        if self.shape_memos.is_none() {
            self.scratch.charge::<[ShapeMemo; SHAPE_MEMOS]>(1)?;
            self.shape_memos = Some(Box::new(
                [ShapeMemo {
                    a: MISSING,
                    b: MISSING,
                    result: MISSING,
                }; SHAPE_MEMOS],
            ));
        }
        let cached = self.shape_memos.as_ref().unwrap()[slot];
        if cached.a == op && cached.b == child {
            return Ok(cached.result);
        }
        let result = self.intern(op, child, &[])?;
        self.shape_memos.as_mut().unwrap()[slot] = ShapeMemo {
            a: op,
            b: child,
            result,
        };
        Ok(result)
    }

    fn join(&mut self, a: i64, b: i64, depth: usize) -> Checked<i64> {
        self.open()?;
        self.check(a)?;
        self.check(b)?;
        if depth > MAX_DEPTH {
            return Err(Error::TypeNestingLimit);
        }
        if a == b || b == -17 {
            return Ok(a);
        }
        if a == -17 {
            return Ok(b);
        }
        let a_op = self.op(a);
        let b_op = self.op(b);
        if a == -1 {
            return Ok(if b_op == -18 { b } else { self.unary(-18, b)? });
        }
        if b == -1 {
            return Ok(if a_op == -18 { a } else { self.unary(-18, a)? });
        }
        if a_op != -20 || b_op != -20 {
            return Ok(self.join_compound(a, b, a_op, b_op, depth)?);
        }
        // Optional-field presence patterns recur in record vectors. Share
        // the bounded per-call memo with unary shapes.
        let (a, b) = if a < b { (a, b) } else { (b, a) };
        let key = ((a as u64).rotate_left(7) ^ b as u64).wrapping_mul(0x9e37_79b1_85eb_ca87);
        let slot = (key >> 32) as usize & (SHAPE_MEMOS - 1);
        if self.shape_memos.is_none() {
            self.scratch.charge::<[ShapeMemo; SHAPE_MEMOS]>(1)?;
            self.shape_memos = Some(Box::new(
                [ShapeMemo {
                    a: MISSING,
                    b: MISSING,
                    result: MISSING,
                }; SHAPE_MEMOS],
            ));
        }
        let cached = self.shape_memos.as_ref().unwrap()[slot];
        // Near the depth limit, replay the recursive checks: a shallow cache
        // entry must not bypass an inner join that would exceed MAX_DEPTH.
        if cached.a == a && cached.b == b && depth + self.height(cached.result) <= MAX_DEPTH {
            return Ok(cached.result);
        }
        let result = self.join_compound(a, b, a_op, b_op, depth)?;
        self.shape_memos.as_mut().unwrap()[slot] = ShapeMemo { a, b, result };
        Ok(result)
    }

    // Keep the non-record path free of another function call and op loads.
    #[inline(always)]
    fn join_compound(
        &mut self,
        a: i64,
        b: i64,
        a_op: i64,
        b_op: i64,
        depth: usize,
    ) -> Checked<i64> {
        if a_op == -18 || b_op == -18 {
            let left = if a_op == -18 {
                self.nodes[a as usize].child
            } else {
                a
            };
            let right = if b_op == -18 {
                self.nodes[b as usize].child
            } else {
                b
            };
            let child = self.join(left, right, depth + 1)?;
            return Ok(self.unary(-18, child)?);
        }
        if a_op != b_op || ![-19, -20, -21].contains(&a_op) {
            return Err(Error::IncompatibleValueShapes);
        }
        if a_op == -19 {
            let left = self.nodes[a as usize].child;
            let right = self.nodes[b as usize].child;
            let child = self.join(left, right, depth + 1)?;
            return Ok(self.unary(-19, child)?);
        }
        while self.joins.len() <= depth {
            self.scratch.push(&mut self.joins, Vec::new())?;
        }
        let mut fields = take(&mut self.joins[depth]);
        fields.clear();
        let left_len = self.nodes[a as usize].fields.len();
        let right_len = self.nodes[b as usize].fields.len();
        let mut left = 0;
        let mut right = 0;
        let mut height = 1;
        while left < left_len || right < right_len {
            let l = self.nodes[a as usize].fields.get(left).copied();
            let r = self.nodes[b as usize].fields.get(right).copied();
            let (field, child) = match (l, r) {
                (Some(l), Some(r)) if l.id == r.id => {
                    left += 1;
                    right += 1;
                    (l, self.join(l.child, r.child, depth + 1)?)
                }
                (Some(l), r) if r.is_none_or(|r| l.id < r.id) => {
                    left += 1;
                    (
                        l,
                        if a_op == -20 {
                            self.join(l.child, -1, depth + 1)?
                        } else {
                            l.child
                        },
                    )
                }
                (_, Some(r)) => {
                    right += 1;
                    (
                        r,
                        if a_op == -20 {
                            self.join(-1, r.child, depth + 1)?
                        } else {
                            r.child
                        },
                    )
                }
                _ => return Err(Error::InvalidShapeUnion),
            };
            height = height.max(self.height(child) + 1);
            self.scratch.push(
                &mut fields,
                Field {
                    id: field.id,
                    child,
                },
            )?;
        }
        let result = self.intern_validated(a_op, MISSING, &fields, height)?;
        self.joins[depth] = fields;
        Ok(result)
    }

    fn join_begin(&mut self) -> Checked<()> {
        self.open()?;
        if self.joining > MAX_DEPTH {
            return Err(Error::TypeNestingLimit);
        }
        if self.joining == self.joiners.len() {
            self.scratch.push(
                &mut self.joiners,
                Joiner {
                    levels: Vec::new(),
                    last: MISSING,
                },
            )?;
        }
        let joiner = &mut self.joiners[self.joining];
        joiner.levels.clear();
        joiner.last = MISSING;
        self.joining += 1;

        Ok(())
    }

    fn join_push(&mut self, mut t: i64) -> Checked<()> {
        self.open()?;
        self.check(t)?;
        let position = self
            .joining
            .checked_sub(1)
            .ok_or(Error::MissingShapeJoiner)?;
        // Identical adjacent elements have the same union. Avoid advancing
        // the reduction tree for long homogeneous runs (including scalars).
        if self.joiners[position].last == t {
            return Ok(());
        }
        self.joiners[position].last = t;
        let mut level = 0;
        loop {
            let levels = &mut self.joiners[position].levels;
            if level == levels.len() {
                self.scratch.push(levels, t)?;
                return Ok(());
            }
            let left = levels[level];
            if left == MISSING {
                levels[level] = t;
                return Ok(());
            }
            levels[level] = MISSING;
            t = self.join(left, t, 0)?;
            level += 1;
        }
    }

    fn join_end(&mut self) -> Checked<i64> {
        self.open()?;
        self.joining = self
            .joining
            .checked_sub(1)
            .ok_or(Error::MissingShapeJoiner)?;
        let position = self.joining;
        let mut joined = -17;
        // Higher levels precede lower levels in source order. The join is a
        // least upper bound, so balancing changes only intermediate shapes.
        for level in (0..self.joiners[position].levels.len()).rev() {
            let next = self.joiners[position].levels[level];
            if next != MISSING {
                joined = self.join(joined, next, 0)?;
            }
        }
        Ok(joined)
    }

    fn root(&mut self, t: i64) -> Checked<()> {
        self.open()?;
        self.check(t)?;
        if self.roots.len() >= MAX_ITEMS {
            return Err(Error::CollectionLengthLimit);
        }
        self.scratch.push(&mut self.roots, t)?;

        Ok(())
    }

    #[inline(always)]
    fn root_type(&self, position: u64) -> Checked<i64> {
        self.roots
            .get(index(position)?)
            .copied()
            .ok_or(Error::RootIndexRange)
    }

    #[inline(always)]
    fn child(&self, t: i64) -> Checked<i64> {
        self.check(t)?;
        if ![-18, -19].contains(&self.op(t)) {
            return Err(Error::MissingUnaryShape);
        }
        Ok(self.nodes[t as usize].child)
    }

    #[inline(always)]
    fn field_type(&self, t: i64, id: u64) -> Checked<i64> {
        self.check(t)?;
        if ![-20, -21].contains(&self.op(t)) {
            return Err(Error::MissingFieldShape);
        }
        let fields = &self.nodes[t as usize].fields;
        Ok(fields
            .binary_search_by_key(&label(id)?, |field| field.id)
            .map(|position| fields[position].child)
            .unwrap_or(MISSING))
    }

    #[inline(always)]
    fn case_index(&self, t: i64, id: u64) -> Checked<u64> {
        self.check(t)?;
        if self.op(t) != -21 {
            return Err(Error::MissingVariantShape);
        }
        self.nodes[t as usize]
            .fields
            .binary_search_by_key(&label(id)?, |field| field.id)
            .map(|position| position as u64)
            .map_err(|_| Error::MissingDerivedVariant)
    }

    fn number(&mut self, t: i64, depth: usize) -> Checked<()> {
        if t < 0 {
            return Ok(());
        }
        let id = t as usize;
        if depth
            .checked_add(self.nodes[id].height)
            .is_none_or(|n| n > MAX_DEPTH + 1)
        {
            return Err(Error::TypeNestingLimit);
        }
        if self.wire_ids[id] != MISSING {
            return Ok(());
        }
        if self.table.len() >= MAX_TYPES {
            return Err(Error::OutputTypeTableLimit);
        }
        self.wire_ids[id] = self.table.len() as i64;
        self.scratch.push(&mut self.table, t)?;
        let op = self.nodes[id].op;
        if [-18, -19].contains(&op) {
            self.number(self.nodes[id].child, depth + 1)?;
        } else {
            for field in 0..self.nodes[id].fields.len() {
                self.number(self.nodes[id].fields[field].child, depth + 1)?;
            }
        }

        Ok(())
    }

    fn reference(&self, t: i64) -> i64 {
        if t < 0 {
            t
        } else {
            self.wire_ids[t as usize]
        }
    }
    fn header(&self, out: &mut Header) -> Checked<()> {
        for byte in b"DIDL" {
            out.byte(*byte)?;
        }
        out.unsigned(self.table.len() as u64)?;
        for t in &self.table {
            let node = &self.nodes[*t as usize];
            out.signed(node.op)?;
            if [-18, -19].contains(&node.op) {
                out.signed(self.reference(node.child))?;
            } else {
                out.unsigned(node.fields.len() as u64)?;
                for field in &node.fields {
                    out.unsigned(u64::from(field.id))?;
                    out.signed(self.reference(field.child))?;
                }
            }
        }
        out.unsigned(self.roots.len() as u64)?;
        for root in &self.roots {
            out.signed(self.reference(*root))?;
        }

        Ok(())
    }

    fn types_size(&mut self) -> Checked<usize> {
        if let Some(size) = self.header_size {
            return Ok(size);
        }
        if self.building != 0 {
            return Err(Error::UnfinishedFieldBuilder);
        }
        if self.joining != 0 {
            return Err(Error::UnfinishedShapeJoiner);
        }
        self.scratch.reserve(&mut self.wire_ids, self.nodes.len())?;
        self.wire_ids.resize(self.nodes.len(), MISSING);
        for root in 0..self.roots.len() {
            self.number(self.roots[root], 0)?;
        }
        let mut out = Header::new(None);
        self.header(&mut out)?;
        self.header_size = Some(out.position);
        Ok(out.position)
    }

    unsafe fn write_types(&mut self, ptr: usize) -> Checked<usize> {
        let size = self.types_size()?;
        if ptr == 0 || ptr.checked_add(size).is_none() {
            return Err(Error::HeaderPointerRange);
        }
        let mut out = Header::new(Some(ptr));
        self.header(&mut out)?;
        if out.position != size {
            return Err(Error::HeaderSizeChanged);
        }
        Ok(out.position)
    }
}

struct Header {
    ptr: Option<usize>,
    position: usize,
}
impl Header {
    fn new(ptr: Option<usize>) -> Self {
        Self { ptr, position: 0 }
    }
    #[inline(always)]
    fn byte(&mut self, byte: u8) -> Checked<()> {
        if self.position >= MAX_BYTES {
            return Err(Error::OutputByteLimit);
        }
        if let Some(ptr) = self.ptr {
            // Generated code supplies an exclusively owned final Blob with
            // capacity at least the checked header and payload size.
            unsafe { (ptr as *mut u8).add(self.position).write(byte) };
        }
        self.position += 1;

        Ok(())
    }

    #[inline(always)]
    fn unsigned(&mut self, mut value: u64) -> Checked<()> {
        loop {
            let byte = (value & 127) as u8;
            value >>= 7;
            self.byte(byte | if value == 0 { 0 } else { 128 })?;
            if value == 0 {
                return Ok(());
            }
        }
    }

    #[inline(always)]
    fn signed(&mut self, mut value: i64) -> Checked<()> {
        loop {
            let byte = (value & 127) as u8;
            value >>= 7;
            let done = (value == 0 && byte < 64) || (value == -1 && byte >= 64);
            self.byte(byte | if done { 0 } else { 128 })?;
            if done {
                return Ok(());
            }
        }
    }
}

// Contexts and borrowed pointers remain within one synchronous generated call.
unsafe fn context<'a>(ctx: usize) -> Checked<&'a mut Context> {
    if ctx == 0 {
        return Err(Error::NullShapeContext);
    }
    Ok(unsafe { &mut *(ctx as *mut Context) })
}

#[unsafe(no_mangle)]
pub(crate) extern "C" fn candid_canonical_new() -> usize {
    Box::into_raw(Box::new(Context::new())) as usize
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_visit(ctx: usize, depth: u64, count: u64) -> i64 {
    match unsafe { (|| context(ctx)?.visit(depth, count))() } {
        Ok(()) => 0,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_begin(ctx: usize, op: i64) -> i64 {
    match unsafe { (|| context(ctx)?.begin(op))() } {
        Ok(()) => 0,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_field(ctx: usize, id: u64, child: i64) -> i64 {
    match unsafe { (|| context(ctx)?.field(id, child))() } {
        Ok(()) => 0,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_end(ctx: usize) -> i64 {
    match unsafe { (|| context(ctx)?.end())() } {
        Ok(value) => value,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_variant(ctx: usize, id: u64, child: i64) -> i64 {
    match unsafe { (|| context(ctx)?.variant(id, child))() } {
        Ok(value) => value,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_unary(ctx: usize, op: i64, child: i64) -> i64 {
    match unsafe { (|| context(ctx)?.unary(op, child))() } {
        Ok(value) => value,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_join(ctx: usize, a: i64, b: i64) -> i64 {
    match unsafe { (|| context(ctx)?.join(a, b, 0))() } {
        Ok(value) => value,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_join_begin(ctx: usize) -> i64 {
    match unsafe { (|| context(ctx)?.join_begin())() } {
        Ok(()) => 0,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_join_push(ctx: usize, t: i64) -> i64 {
    match unsafe { (|| context(ctx)?.join_push(t))() } {
        Ok(()) => 0,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_join_end(ctx: usize) -> i64 {
    match unsafe { (|| context(ctx)?.join_end())() } {
        Ok(value) => value,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_root(ctx: usize, t: i64) -> i64 {
    match unsafe { (|| context(ctx)?.root(t))() } {
        Ok(()) => 0,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_root_type(ctx: usize, index: u64) -> i64 {
    match unsafe { (|| context(ctx)?.root_type(index))() } {
        Ok(value) => value,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_types_size(ctx: usize) -> i64 {
    match unsafe { (|| context(ctx)?.types_size())() } {
        Ok(value) => value as i64,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_write_types(ctx: usize, ptr: usize) -> i64 {
    match unsafe { (|| context(ctx)?.write_types(ptr))() } {
        Ok(value) => value as i64,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_child(ctx: usize, t: i64) -> i64 {
    match unsafe { (|| context(ctx)?.child(t))() } {
        Ok(value) => value,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_field_type(ctx: usize, t: i64, id: u64) -> i64 {
    match unsafe { (|| context(ctx)?.field_type(t, id))() } {
        Ok(value) => value,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_case_index(ctx: usize, t: i64, id: u64) -> i64 {
    match unsafe { (|| context(ctx)?.case_index(t, id))() } {
        Ok(value) => value as i64,
        Err(error) => status(error),
    }
}
#[unsafe(no_mangle)]
pub(crate) unsafe extern "C" fn candid_canonical_done(ctx: usize) {
    if ctx != 0 {
        unsafe { drop(Box::from_raw(ctx as *mut Context)) };
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use alloc::vec;
    use std::panic::{catch_unwind, AssertUnwindSafe};

    fn compound(ctx: &mut Context, op: i64, fields: &[(u32, i64)]) -> i64 {
        ctx.begin(op).unwrap();
        for (id, child) in fields {
            ctx.field(u64::from(*id), *child).unwrap();
        }
        ctx.end().unwrap()
    }
    fn bytes(ctx: &mut Context) -> Vec<u8> {
        let size = ctx.types_size().unwrap();
        let mut output = vec![0xaa; size + 1];
        assert_eq!(
            unsafe { ctx.write_types(output.as_mut_ptr() as usize).unwrap() },
            size
        );
        assert_eq!(output.pop(), Some(0xaa));
        output
    }
    fn rejects(f: impl FnOnce()) {
        assert!(catch_unwind(AssertUnwindSafe(f)).is_err());
    }

    #[test]
    fn abi_reports_errors_without_unwinding_or_retaining_call_state() {
        for (depth, count, message) in [
            (257, 0, Error::ValueNestingLimit),
            (0, 2_000_001, Error::ValueTraversalLimit),
        ] {
            let ctx = candid_canonical_new();
            unsafe {
                assert_eq!(candid_canonical_visit(ctx, depth, count), status(message));
                candid_canonical_done(ctx);
            }
        }
        let ctx = candid_canonical_new();
        unsafe {
            // Discarding incomplete builders after an error is also valid.
            assert_eq!(candid_canonical_begin(ctx, -20), 0);
            assert_eq!(
                candid_canonical_field(ctx, u64::MAX, -1),
                status(Error::FieldIdRange)
            );
            candid_canonical_done(ctx);
        }
        let ctx = candid_canonical_new();
        unsafe {
            assert_eq!(candid_canonical_root(ctx, -3), 0);
            assert!(candid_canonical_types_size(ctx) > 0);
            candid_canonical_done(ctx);
        }
        let mut ctx = Context::new();
        ctx.scratch.limit = ctx.scratch.used;
        assert_eq!(ctx.unary(-18, -1), Err(Error::ScratchByteLimit));
    }

    #[test]
    fn error_statuses_match_the_compiler_and_cannot_alias_shape_values() {
        let compiler = include_str!("../../compiler/errors.ml");
        let compiler_messages: Vec<_> = compiler
            .lines()
            .filter_map(|line| {
                line.strip_prefix("  \"")
                    .and_then(|text| text.strip_suffix("\";"))
            })
            .collect();
        assert_eq!(compiler_messages, ERRORS);
        for i in 0..ERRORS.len() {
            let code = ERROR_BASE + i as i64;
            assert_eq!(code, ERROR_BASE + i as i64);
            assert!(!primitive(code));
            assert_ne!(code, MISSING);
            assert!(code < 0);
        }
    }

    #[test]
    fn reused_builders_validate_current_fields_and_reset_height() {
        let mut ctx = Context::new();
        let original = compound(&mut ctx, -20, &[(7, -3)]);
        assert_eq!(compound(&mut ctx, -20, &[(7, -3)]), original);
        let variant = compound(&mut ctx, -21, &[(7, -3)]);
        assert_ne!(variant, original);
        assert_eq!(compound(&mut ctx, -20, &[(7, -3)]), original);
        assert_ne!(compound(&mut ctx, -20, &[(8, -3)]), original);
        let optional = ctx.unary(-18, -3).unwrap();
        assert_ne!(compound(&mut ctx, -20, &[(7, optional)]), original);
        ctx.begin(-20).unwrap();
        rejects(|| {
            ctx.field(7, -22).unwrap();
        });
        let empty = ctx.end().unwrap();
        assert_eq!(ctx.height(empty), 1);
        let mut child = -1;
        for _ in 0..MAX_DEPTH {
            child = ctx.unary(-19, child).unwrap();
        }
        let deep = compound(&mut ctx, -20, &[(0, child)]);
        assert_eq!(ctx.height(deep), MAX_DEPTH + 1);
        let too_deep = ctx.unary(-18, child).unwrap();
        rejects(|| {
            compound(&mut ctx, -20, &[(0, too_deep)]);
        });
        assert_eq!(compound(&mut ctx, -20, &[]), empty);
        // Missing record fields lift a nonoptional child; their new parent
        // height must be checked even though both input records are valid.
        rejects(|| {
            ctx.join(deep, empty, 0).unwrap();
        });
    }

    #[test]
    fn unary_memo_does_not_bypass_reference_depth_or_finalization_checks() {
        let mut ctx = Context::new();
        let opt = ctx.unary(-18, -3).unwrap();
        let vec = ctx.unary(-19, -3).unwrap();
        assert_eq!(ctx.unary(-18, -3).unwrap(), opt);
        assert_eq!(ctx.unary(-19, -3).unwrap(), vec);
        rejects(|| {
            ctx.unary(-18, -22).unwrap();
        });
        rejects(|| {
            ctx.unary(-19, MISSING).unwrap();
        });
        let mut child = -1;
        for _ in 0..=MAX_DEPTH {
            child = ctx.unary(-18, child).unwrap();
        }
        rejects(|| {
            ctx.unary(-18, child).unwrap();
        });
        ctx.root(opt).unwrap();
        ctx.types_size().unwrap();
        rejects(|| {
            ctx.unary(-18, -3).unwrap();
        });
        rejects(|| {
            ctx.unary(-19, -3).unwrap();
        });
        let mut ctx = Context::new();
        ctx.scratch.limit = ctx.scratch.used;
        rejects(|| {
            ctx.unary(-18, -3).unwrap();
        });
    }

    #[test]
    fn singleton_variants_match_builders_and_preserve_outer_record_builder() {
        let mut ctx = Context::new();
        let option = ctx.unary(-18, -3).unwrap();
        let empty = ctx.unary(-19, -17).unwrap();
        let record = compound(&mut ctx, -20, &[(7, -3)]);
        for child in [-1, -3, -5, option, empty, record] {
            for id in [0, 1, 128, u32::MAX] {
                let expected = compound(&mut ctx, -21, &[(id, child)]);
                assert_eq!(ctx.variant(u64::from(id), child).unwrap(), expected);
                assert_eq!(ctx.case_index(expected, u64::from(id)).unwrap(), 0);
                assert_eq!(ctx.field_type(expected, u64::from(id)).unwrap(), child);
            }
        }
        ctx.begin(-20).unwrap();
        let nested = ctx.variant(123, -1).unwrap();
        ctx.field(7, nested).unwrap();
        let record = ctx.end().unwrap();
        assert_eq!(ctx.field_type(record, 7).unwrap(), nested);
        ctx.root(record).unwrap();
        assert_eq!(
            bytes(&mut ctx),
            b"DIDL\x02\x6c\x01\x07\x01\x6b\x01\x7b\x7f\x01\x00"
        );
    }

    #[test]
    fn singleton_variants_enforce_reference_label_depth_and_lifecycle_limits() {
        let mut ctx = Context::new();
        rejects(|| {
            ctx.variant(0, -22).unwrap();
        });
        rejects(|| {
            ctx.variant(u64::from(u32::MAX) + 1, -1).unwrap();
        });
        let mut child = -1;
        for _ in 0..MAX_DEPTH {
            child = ctx.variant(0, child).unwrap();
        }
        child = ctx.variant(0, child).unwrap();
        rejects(|| {
            ctx.variant(0, child).unwrap();
        });
        ctx.root(child).unwrap();
        ctx.types_size().unwrap();
        rejects(|| {
            ctx.variant(0, -1).unwrap();
        });
        let mut ctx = Context::new();
        ctx.scratch.limit = ctx.scratch.used;
        rejects(|| {
            ctx.variant(0, -1).unwrap();
        });
    }

    #[test]
    fn cached_record_joins_recheck_relative_nesting_limits() {
        let mut ctx = Context::new();
        let opt = ctx.unary(-18, -3).unwrap();
        let left = compound(&mut ctx, -20, &[(0, -3)]);
        let right = compound(&mut ctx, -20, &[(0, opt)]);
        assert_eq!(ctx.join(left, right, 0).unwrap(), right);
        for wrappers in [MAX_DEPTH - 2, MAX_DEPTH - 1] {
            let mut a = left;
            let mut b = right;
            for _ in 0..wrappers {
                a = ctx.unary(-18, a).unwrap();
                b = ctx.unary(-18, b).unwrap();
            }
            if wrappers == MAX_DEPTH - 2 {
                assert_eq!(ctx.join(a, b, 0).unwrap(), b);
            } else {
                rejects(|| {
                    ctx.join(a, b, 0).unwrap();
                });
            }
        }
        assert_eq!(ctx.shape_memos.as_ref().unwrap().len(), SHAPE_MEMOS);
    }

    #[test]
    fn memo_storage_is_lazy_and_reused_by_records_and_options() {
        let mut ctx = Context::new();
        let a = compound(&mut ctx, -21, &[(0, -1)]);
        let b = compound(&mut ctx, -21, &[(1, -1)]);
        let variants = ctx.join(a, b, 0).unwrap();
        assert!(ctx.shape_memos.is_none());
        ctx.unary(-19, variants).unwrap();
        assert!(ctx.shape_memos.is_none());
        let a = ctx.unary(-18, a).unwrap();
        let b = ctx.unary(-18, b).unwrap();
        let wanted = ctx.unary(-18, variants).unwrap();
        assert_eq!(ctx.join(a, b, 0).unwrap(), wanted);
        assert!(ctx.shape_memos.is_some());
        let a = compound(&mut ctx, -20, &[(0, -1)]);
        let b = compound(&mut ctx, -20, &[(1, -1)]);
        let wanted = ctx.join(a, b, 0).unwrap();
        assert_eq!(ctx.shape_memos.as_ref().unwrap().len(), SHAPE_MEMOS);
        let scratch = ctx.scratch.used;
        for _ in 0..1024 {
            assert_eq!(ctx.join(a, b, 0).unwrap(), wanted);
            assert_eq!(ctx.join(b, a, 0).unwrap(), wanted);
        }
        assert_eq!(ctx.scratch.used, scratch);
    }

    #[test]
    fn interning_spreads_structured_field_labels_across_the_table() {
        let mut ctx = Context::new();
        for family in 0..4 {
            for id in 0u32..8192 {
                let id = match family {
                    0 => id,
                    1 => id.rotate_left(16),
                    2 => id.wrapping_mul(0x10001),
                    _ => id.wrapping_mul(223),
                };
                compound(&mut ctx, -21, &[(id, -1)]);
            }
        }
        let mut total_probes = 0;
        let mut longest_probe = 0;
        for (id, node) in ctx.nodes.iter().enumerate() {
            let mut slot = node.hash as usize & (ctx.slots.len() - 1);
            let mut probes = 1;
            while ctx.slots[slot] != id + 1 {
                assert_ne!(ctx.slots[slot], 0);
                slot = (slot + 1) & (ctx.slots.len() - 1);
                probes += 1;
            }
            total_probes += probes;
            longest_probe = longest_probe.max(probes);
        }
        assert!(total_probes < 4 * ctx.nodes.len());
        assert!(longest_probe < 128);
    }

    #[test]
    fn frozen_headers_and_dfs_numbering_are_independent_of_intern_order() {
        let mut ctx = Context::new();
        assert_eq!(bytes(&mut ctx), b"DIDL\0\0");
        let mut ctx = Context::new();
        ctx.root(-3).unwrap();
        assert_eq!(bytes(&mut ctx), b"DIDL\0\x01\x7d");
        let mut ctx = Context::new();
        let blob = ctx.unary(-19, -5).unwrap();
        ctx.root(blob).unwrap();
        assert_eq!(bytes(&mut ctx), b"DIDL\x01\x6d\x7b\x01\x00");
        let mut ctx = Context::new();
        let opt = ctx.unary(-18, -1).unwrap();
        let record = compound(&mut ctx, -20, &[(0, -1), (1, -16), (3, opt)]);
        ctx.root(record).unwrap();
        assert_eq!(
            bytes(&mut ctx),
            b"DIDL\x02\x6c\x03\x00\x7f\x01\x70\x03\x01\x6e\x7f\x01\x00"
        );
        let mut ctx = Context::new();
        let opt = ctx.unary(-18, -3).unwrap();
        let record = compound(&mut ctx, -20, &[(0, opt)]);
        ctx.root(record).unwrap();
        ctx.root(opt).unwrap();
        assert_eq!(
            bytes(&mut ctx),
            b"DIDL\x02\x6c\x01\x00\x01\x6e\x7d\x02\x00\x01"
        );
    }

    #[test]
    fn join_retains_scalar_option_and_empty_vector_rules() {
        let mut ctx = Context::new();
        let opt = ctx.unary(-18, -3).unwrap();
        assert_eq!(ctx.join(-1, -3, 0).unwrap(), opt);
        assert_eq!(ctx.join(-3, -1, 0).unwrap(), opt);
        assert_eq!(ctx.join(-1, opt, 0).unwrap(), opt);
        assert_eq!(ctx.join(opt, -3, 0).unwrap(), opt);
        assert_eq!(ctx.join(-17, opt, 0).unwrap(), opt);
        assert_eq!(ctx.join(opt, -17, 0).unwrap(), opt);
        let empty = ctx.unary(-19, -17).unwrap();
        let blob = ctx.unary(-19, -5).unwrap();
        assert_eq!(ctx.join(empty, blob, 0).unwrap(), blob);
        let opt_null = ctx.unary(-18, -1).unwrap();
        let nested = ctx.join(opt_null, opt, 0).unwrap();
        assert_eq!(ctx.child(nested).unwrap(), opt);
        rejects(|| {
            ctx.join(-3, -8, 0).unwrap();
        });
    }

    #[test]
    fn records_lift_missing_fields_and_variants_union_selected_cases() {
        let mut ctx = Context::new();
        let a = compound(&mut ctx, -20, &[(0, -15)]);
        let opt = ctx.unary(-18, -15).unwrap();
        let b = compound(&mut ctx, -20, &[(0, -15), (9, opt)]);
        assert_eq!(ctx.join(a, b, 0).unwrap(), b);
        assert_eq!(ctx.join(b, a, 0).unwrap(), b);
        let c = compound(&mut ctx, -20, &[(9, -15)]);
        let joined = ctx.join(a, c, 0).unwrap();
        assert_eq!(ctx.field_type(joined, 0).unwrap(), opt);
        assert_eq!(ctx.field_type(joined, 9).unwrap(), opt);
        assert_eq!(ctx.field_type(joined, 10).unwrap(), MISSING);
        let a = compound(&mut ctx, -21, &[(91, -1)]);
        let b = compound(&mut ctx, -21, &[(3, -2)]);
        let joined = ctx.join(a, b, 0).unwrap();
        assert_eq!(ctx.case_index(joined, 3).unwrap(), 0);
        assert_eq!(ctx.case_index(joined, 91).unwrap(), 1);
        assert_eq!(ctx.field_type(joined, 91).unwrap(), -1);
        assert_eq!(ctx.join(joined, a, 0).unwrap(), joined);
    }

    fn balanced(ctx: &mut Context, shapes: &[i64]) -> i64 {
        ctx.join_begin().unwrap();
        for shape in shapes {
            ctx.join_push(*shape).unwrap();
        }
        ctx.join_end().unwrap()
    }

    #[test]
    fn balanced_joins_match_sequential_joins_of_nested_optional_shapes() {
        let mut ctx = Context::new();
        let nat = ctx.unary(-18, -3).unwrap();
        let present_absent = ctx.unary(-18, -1).unwrap();
        let present_present = ctx.unary(-18, nat).unwrap();
        let mut shapes = vec![];
        for value in 0..27 {
            let mut states = value;
            ctx.begin(-20).unwrap();
            for id in 0..3 {
                match states % 3 {
                    0 => (),
                    1 => ctx.field(id, present_absent).unwrap(),
                    2 => ctx.field(id, present_present).unwrap(),
                    _ => unreachable!(),
                }
                states /= 3;
            }
            shapes.push(ctx.end().unwrap());
        }
        // All triples exercise reassociation through every combination of
        // omitted fields and the two nested option levels, not just pairs.
        for a in &shapes {
            for b in &shapes {
                for c in &shapes {
                    let left = ctx.join(*a, *b, 0).unwrap();
                    let expected = ctx.join(left, *c, 0).unwrap();
                    assert_eq!(balanced(&mut ctx, &[*a, *b, *c]), expected);
                    let right = ctx.join(*b, *c, 0).unwrap();
                    assert_eq!(ctx.join(*a, right, 0).unwrap(), expected);
                }
            }
        }
        let empty = ctx.unary(-19, -17).unwrap();
        let mut cases = vec![compound(&mut ctx, -21, &[(200, empty)])];
        for record in shapes {
            for id in [3, 91] {
                let vector = ctx.unary(-19, record).unwrap();
                cases.push(compound(&mut ctx, -21, &[(id, vector)]));
            }
        }
        for length in 0..128 {
            let mut sequence = vec![];
            let mut expected = -17;
            for i in 0..length {
                let shape = cases[(i * 17 + length * 11) % cases.len()];
                sequence.push(shape);
                expected = ctx.join(expected, shape, 0).unwrap();
            }
            assert_eq!(balanced(&mut ctx, &sequence), expected);
        }
    }

    #[test]
    fn balanced_joins_reuse_scratch_and_keep_nested_accumulators_separate() {
        let mut ctx = Context::new();
        let a = compound(&mut ctx, -21, &[(0, -1)]);
        let b = compound(&mut ctx, -21, &[(1, -1)]);
        let wanted = ctx.join(a, b, 0).unwrap();
        ctx.join_begin().unwrap();
        ctx.join_push(a).unwrap();
        let scratch = ctx.scratch.used;
        for _ in 0..10_000 {
            ctx.join_push(a).unwrap();
        }
        assert_eq!(ctx.scratch.used, scratch);
        let inner = balanced(&mut ctx, &[a, a, b, b, a]);
        assert_eq!(inner, wanted);
        ctx.join_push(inner).unwrap();
        assert_eq!(ctx.join_end().unwrap(), wanted);
        let scratch = ctx.scratch.used;
        for _ in 0..10 {
            assert_eq!(balanced(&mut ctx, &[a, a, b, b, a]), wanted);
        }
        assert_eq!(ctx.scratch.used, scratch);
        assert_eq!(balanced(&mut ctx, &[]), -17);
    }

    #[test]
    fn wide_variant_vectors_stay_below_the_scratch_limit() {
        let mut ctx = Context::new();
        ctx.join_begin().unwrap();
        for id in 0..6000 {
            let shape = compound(&mut ctx, -21, &[(id, -1)]);
            ctx.join_push(shape).unwrap();
        }
        let variant = ctx.join_end().unwrap();
        for id in 0..6000 {
            assert_eq!(ctx.case_index(variant, id).unwrap(), id);
            assert_eq!(ctx.field_type(variant, id).unwrap(), -1);
        }
        let vector = ctx.unary(-19, variant).unwrap();
        ctx.root(vector).unwrap();
        let header = bytes(&mut ctx);
        assert_eq!(ctx.table.len(), 2);
        // The sequential reduction exceeds the 256 MiB hard limit here,
        // despite this vector's type header requiring less than 18 KiB.
        assert!(header.len() < 18_000);
        assert!(ctx.scratch.used < 8 * 1024 * 1024);
    }

    #[test]
    fn unfinished_and_missing_shape_accumulators_reject() {
        let mut ctx = Context::new();
        rejects(|| {
            ctx.join_push(-1).unwrap();
        });
        rejects(|| {
            ctx.join_end().unwrap();
        });
        ctx.join_begin().unwrap();
        rejects(|| {
            ctx.types_size().unwrap();
        });
        ctx.join_end().unwrap();
        ctx.types_size().unwrap();
        rejects(|| {
            ctx.join_begin().unwrap();
        });
    }

    #[test]
    fn structurally_equal_builds_and_repeated_joins_reuse_scratch() {
        let mut ctx = Context::new();
        let a = compound(&mut ctx, -20, &[(0, -3), (1, -24)]);
        let b = compound(&mut ctx, -20, &[(0, -3)]);
        let joined = ctx.join(a, b, 0).unwrap();
        let allocated = ctx.scratch.used;
        for _ in 0..1024 {
            assert_eq!(compound(&mut ctx, -20, &[(0, -3), (1, -24)]), a);
            assert_eq!(compound(&mut ctx, -20, &[(0, -3)]), b);
            assert_eq!(ctx.join(a, b, 0).unwrap(), joined);
            assert_eq!(ctx.join(joined, b, 0).unwrap(), joined);
        }
        assert_eq!(ctx.scratch.used, allocated);
        assert_eq!(ctx.nodes.len(), 4);
    }

    #[test]
    fn all_optional_presence_pairs_match_their_independent_expected_union() {
        let mut ctx = Context::new();
        let inner = ctx.unary(-18, -3).unwrap();
        let present_absent = ctx.unary(-18, -1).unwrap();
        let present_present = ctx.unary(-18, inner).unwrap();
        let mut records = Vec::new();
        let mut vectors = Vec::new();
        for value in 0..27 {
            let mut states = value;
            ctx.begin(-20).unwrap();
            for id in 0..3 {
                match states % 3 {
                    0 => (),
                    1 => ctx.field(id, present_absent).unwrap(),
                    2 => ctx.field(id, present_present).unwrap(),
                    _ => unreachable!(),
                }
                states /= 3;
            }
            let record = ctx.end().unwrap();
            records.push(record);
            vectors.push(ctx.unary(-19, record).unwrap());
        }
        for a in 0..27 {
            for b in 0..27 {
                let mut left = a;
                let mut right = b;
                let mut expected = 0;
                let mut place = 1;
                for _ in 0..3 {
                    expected += (left % 3).max(right % 3) * place;
                    left /= 3;
                    right /= 3;
                    place *= 3;
                }
                assert_eq!(
                    ctx.join(records[a], records[b], 0).unwrap(),
                    records[expected]
                );
                assert_eq!(
                    ctx.join(vectors[a], vectors[b], 0).unwrap(),
                    vectors[expected]
                );
                let left = compound(&mut ctx, -21, &[(3, records[a])]);
                let right = compound(&mut ctx, -21, &[(3, records[b])]);
                let wanted = compound(&mut ctx, -21, &[(3, records[expected])]);
                assert_eq!(ctx.join(left, right, 0).unwrap(), wanted);
                let right = compound(&mut ctx, -21, &[(91, records[b])]);
                let wanted = compound(&mut ctx, -21, &[(3, records[a]), (91, records[b])]);
                assert_eq!(ctx.join(left, right, 0).unwrap(), wanted);
            }
        }
    }

    #[test]
    fn only_reachable_types_count_toward_the_final_table_limit() {
        let mut ctx = Context::new();
        for id in 0..1500 {
            compound(&mut ctx, -20, &[(id, -1)]);
        }
        ctx.root(0).unwrap();
        ctx.types_size().unwrap();
        assert_eq!(ctx.table.len(), 1);
        let mut ctx = Context::new();
        for id in 0..1025 {
            let record = compound(&mut ctx, -20, &[(id, -1)]);
            ctx.root(record).unwrap();
        }
        rejects(|| {
            ctx.types_size().unwrap();
        });
    }

    #[test]
    fn bounds_include_old_growth_buffers_and_all_source_visits() {
        let mut scratch = Scratch {
            used: 0,
            limit: MAX_SCRATCH,
        };
        let mut values = Vec::<i64>::new();
        scratch.reserve(&mut values, 1).unwrap();
        let first = scratch.used;
        values.push(1);
        scratch.reserve(&mut values, 2).unwrap();
        assert_eq!(scratch.used, first + allocation_size::<i64>(2).unwrap());
        scratch.limit = scratch.used;
        rejects(|| {
            scratch.reserve(&mut values, 3).unwrap();
        });
        let mut ctx = Context::new();
        ctx.visit(256, 2_000_000).unwrap();
        rejects(|| {
            ctx.visit(256, 1).unwrap();
        });
        rejects(|| {
            Context::new().visit(257, 0).unwrap();
        });
        let mut ctx = Context::new();
        let mut t = ctx.unary(-19, -5).unwrap();
        for _ in 0..256 {
            t = ctx.unary(-18, t).unwrap();
        }
        rejects(|| {
            ctx.unary(-18, t).unwrap();
        });
        ctx.root(t).unwrap();
        ctx.types_size().unwrap();
        assert_eq!(ctx.table.len(), 257);
        let mut out = Header {
            ptr: None,
            position: MAX_BYTES - 1,
        };
        out.byte(0).unwrap();
        assert_eq!(out.position, MAX_BYTES);
        rejects(|| {
            out.byte(0).unwrap();
        });
    }

    #[test]
    fn unsigned_labels_and_signed_type_references_are_minimal() {
        let mut ctx = Context::new();
        let record = compound(&mut ctx, -20, &[(u32::MAX, -1)]);
        ctx.root(record).unwrap();
        assert_eq!(
            bytes(&mut ctx),
            b"DIDL\x01\x6c\x01\xff\xff\xff\xff\x0f\x7f\x01\x00"
        );
        let mut output = [0; 2];
        let mut out = Header::new(Some(output.as_mut_ptr() as usize));
        out.signed(64).unwrap();
        assert_eq!(out.position, 2);
        assert_eq!(output, [0xc0, 0]);
    }

    #[test]
    fn malformed_or_unfinished_builders_and_unsupported_shapes_reject() {
        let mut ctx = Context::new();
        rejects(|| {
            ctx.root(-22).unwrap();
        });
        rejects(|| {
            ctx.unary(-20, -1).unwrap();
        });
        ctx.begin(-20).unwrap();
        ctx.field(2, -1).unwrap();
        rejects(|| {
            ctx.field(1, -1).unwrap();
        });
        rejects(|| {
            ctx.types_size().unwrap();
        });
        ctx.end().unwrap();
        ctx.types_size().unwrap();
        rejects(|| {
            ctx.root(-1).unwrap();
        });
    }

    #[test]
    fn abi_writes_into_the_caller_buffer_and_keeps_internal_refs() {
        unsafe {
            let ctx = candid_canonical_new();
            candid_canonical_visit(ctx, 0, 2);
            let opt = candid_canonical_unary(ctx, -18, -3);
            candid_canonical_begin(ctx, -20);
            candid_canonical_field(ctx, 0, opt);
            let record = candid_canonical_end(ctx);
            candid_canonical_root(ctx, record);
            assert_eq!(candid_canonical_root_type(ctx, 0), record);
            assert_eq!(candid_canonical_child(ctx, opt), -3);
            assert_eq!(candid_canonical_field_type(ctx, record, 0), opt);
            let size = candid_canonical_types_size(ctx) as usize;
            let mut buffer = vec![0; size];
            assert_eq!(
                candid_canonical_write_types(ctx, buffer.as_mut_ptr() as usize),
                size as i64
            );
            assert_eq!(buffer, b"DIDL\x02\x6c\x01\x00\x01\x6e\x7d\x01\x00");
            candid_canonical_done(ctx);
        }
    }
}
