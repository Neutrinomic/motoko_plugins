  (func $_RNvCsakw9nm40atj_19motoko_compute_p25627projective_x_matches_scalar (type 6) (param i64 i64) (result i32)
    (local i64 i32 i64 i64 i64 i64 i64 i32 i64 i64 i64 i64)
    global.get $__stack_pointer
    i64.const 80
    i64.sub
    local.tee 2
    global.set $__stack_pointer
    i32.const 0
    local.set 3
    block  ;; label = @1
      block  ;; label = @2
        local.get 0
        i64.load offset=72
        local.get 0
        i64.load offset=64
        i64.or
        local.get 0
        i64.load offset=80
        i64.or
        local.get 0
        i64.load offset=88
        i64.or
        i64.eqz
        call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
        i32.const 255
        i32.and
        br_if 0 (;@2;)
        local.get 1
        i64.load
        local.set 4
        local.get 1
        i64.load offset=8
        local.set 5
        local.get 1
        i64.load offset=16
        local.set 6
        local.get 2
        local.get 1
        i64.load offset=24
        local.tee 1
        i64.store offset=72
        local.get 2
        local.get 6
        i64.store offset=64
        local.get 2
        local.get 5
        i64.store offset=56
        local.get 2
        local.get 4
        i64.store offset=48
        i32.const 1
        local.set 3
        global.get $__memory_base
        local.set 7
        local.get 4
        i64.const -1
        i64.eq
        i64.extend_i32_u
        i64.const -1
        i64.add
        local.tee 8
        local.get 5
        local.get 8
        i64.add
        local.tee 8
        local.get 5
        i64.lt_u
        i64.extend_i32_u
        i64.add
        local.get 8
        i64.const -4294967295
        i64.add
        local.get 8
        i64.lt_u
        i64.extend_i32_u
        i64.add
        i64.const -1
        i64.add
        i64.const 63
        i64.shr_s
        local.tee 8
        local.get 8
        local.get 6
        i64.add
        local.get 8
        i64.lt_u
        i64.extend_i32_u
        i64.add
        i64.const 63
        i64.shr_s
        local.tee 8
        local.get 1
        local.get 8
        i64.add
        local.tee 8
        local.get 1
        i64.lt_u
        i64.extend_i32_u
        i64.add
        local.get 8
        i64.const 4294967295
        i64.add
        local.get 8
        i64.lt_u
        i64.extend_i32_u
        i64.add
        i32.wrap_i64
        i32.const 1
        i32.add
        i32.const 1
        i32.and
        call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
        local.set 9
        local.get 2
        i64.const 8
        i64.add
        local.get 2
        i64.const 48
        i64.add
        local.get 7
        i64.const 21000
        i64.add
        call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
        local.get 9
        i32.const 255
        i32.and
        i32.const 1
        i32.ne
        br_if 1 (;@1;)
        local.get 2
        local.get 2
        i64.load offset=32
        i64.store offset=72
        local.get 2
        local.get 2
        i64.load offset=24
        i64.store offset=64
        local.get 2
        local.get 2
        i64.load offset=16
        i64.store offset=56
        local.get 2
        local.get 2
        i64.load offset=8
        i64.store offset=48
        local.get 2
        i64.const 8
        i64.add
        local.get 2
        i64.const 48
        i64.add
        local.get 0
        i64.const 64
        i64.add
        local.tee 8
        call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
        local.get 2
        i64.load offset=8
        local.get 0
        i64.load
        local.tee 7
        i64.eq
        local.get 2
        i64.load offset=16
        local.get 0
        i64.load offset=8
        local.tee 10
        i64.eq
        i32.and
        local.get 2
        i64.load offset=24
        local.get 0
        i64.load offset=16
        local.tee 11
        i64.eq
        i32.and
        local.get 2
        i64.load offset=32
        local.get 0
        i64.load offset=24
        local.tee 12
        i64.eq
        i32.and
        call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
        i32.const 255
        i32.and
        br_if 0 (;@2;)
        i32.const 0
        local.set 3
        local.get 6
        local.get 5
        local.get 4
        i64.const -884452912994769583
        i64.add
        local.tee 13
        local.get 4
        i64.lt_u
        i64.extend_i32_u
        i64.add
        local.tee 0
        local.get 5
        i64.lt_u
        i64.extend_i32_u
        local.get 0
        i64.const -4834901526196019580
        i64.add
        local.tee 5
        local.get 0
        i64.lt_u
        i64.extend_i32_u
        i64.add
        i64.add
        local.tee 0
        local.get 6
        i64.lt_u
        i64.extend_i32_u
        local.get 0
        i64.const 0
        i64.ne
        i64.extend_i32_u
        i64.add
        local.tee 6
        local.get 1
        i64.add
        local.tee 1
        i64.const 4294967296
        i64.lt_u
        i32.const 0
        local.get 1
        local.get 6
        i64.ge_u
        select
        call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
        i32.const 255
        i32.and
        i32.const 1
        i32.ne
        br_if 0 (;@2;)
        local.get 2
        local.get 13
        i64.store offset=48
        local.get 2
        local.get 5
        i64.store offset=56
        local.get 2
        local.get 0
        i64.const -1
        i64.add
        local.tee 6
        i64.store offset=64
        local.get 2
        local.get 1
        i64.const -4294967296
        i64.add
        local.tee 0
        i64.store offset=72
        global.get $__memory_base
        local.set 4
        local.get 13
        i64.const -1
        i64.eq
        i64.extend_i32_u
        i64.const -1
        i64.add
        local.tee 1
        local.get 5
        local.get 1
        i64.add
        local.tee 1
        local.get 5
        i64.lt_u
        i64.extend_i32_u
        i64.add
        local.get 1
        i64.const -4294967295
        i64.add
        local.get 1
        i64.lt_u
        i64.extend_i32_u
        i64.add
        i64.const -1
        i64.add
        i64.const 63
        i64.shr_s
        local.tee 1
        local.get 1
        local.get 6
        i64.add
        local.get 1
        i64.lt_u
        i64.extend_i32_u
        i64.add
        i64.const 63
        i64.shr_s
        local.tee 1
        local.get 0
        local.get 1
        i64.add
        local.tee 1
        local.get 0
        i64.lt_u
        i64.extend_i32_u
        i64.add
        local.get 1
        i64.const 4294967295
        i64.add
        local.get 1
        i64.lt_u
        i64.extend_i32_u
        i64.add
        i32.wrap_i64
        i32.const 1
        i32.add
        i32.const 1
        i32.and
        call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
        local.set 9
        local.get 2
        i64.const 8
        i64.add
        local.get 2
        i64.const 48
        i64.add
        local.get 4
        i64.const 21000
        i64.add
        call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
        local.get 9
        i32.const 255
        i32.and
        i32.const 1
        i32.ne
        br_if 0 (;@2;)
        local.get 2
        local.get 2
        i64.load offset=32
        i64.store offset=72
        local.get 2
        local.get 2
        i64.load offset=24
        i64.store offset=64
        local.get 2
        local.get 2
        i64.load offset=16
        i64.store offset=56
        local.get 2
        local.get 2
        i64.load offset=8
        i64.store offset=48
        local.get 2
        i64.const 8
        i64.add
        local.get 2
        i64.const 48
        i64.add
        local.get 8
        call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
        local.get 2
        i64.load offset=8
        local.get 7
        i64.eq
        local.get 2
        i64.load offset=16
        local.get 10
        i64.eq
        i32.and
        local.get 2
        i64.load offset=24
        local.get 11
        i64.eq
        i32.and
        local.get 2
        i64.load offset=32
        local.get 12
        i64.eq
        i32.and
        call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
        i32.const 255
        i32.and
        i32.const 0
        i32.ne
        local.set 3
      end
      local.get 2
      i64.const 80
      i64.add
      global.set $__stack_pointer
      local.get 3
      return
    end
    local.get 2
    i64.const 48
    i64.add
    call $_RINvNtCseJf3vUvalIj_4core9panicking13assert_failedhhECs8m9hhMswt4C_4p256
    unreachable)
