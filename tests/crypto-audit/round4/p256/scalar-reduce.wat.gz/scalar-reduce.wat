  (func $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic6scalar11scalar_impl14barrett_reduce (type 1) (param i64 i64 i64)
    (local i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    global.get $__stack_pointer
    i64.const 512
    i64.sub
    local.tee 3
    global.set $__stack_pointer
    local.get 3
    i64.const 192
    i64.add
    local.get 1
    i64.load offset=24
    local.tee 4
    i64.const 0
    i64.const 85565669623438334
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 208
    i64.add
    local.get 4
    i64.const 0
    i64.const 4834901528447446049
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 224
    i64.add
    local.get 4
    i64.const 0
    i64.const -4294967297
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 240
    i64.add
    local.get 4
    i64.const 0
    i64.const 4294967295
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 496
    i64.add
    local.get 2
    i64.load
    local.tee 5
    i64.const 0
    i64.const 85565669623438334
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 480
    i64.add
    local.get 5
    i64.const 0
    i64.const 4834901528447446049
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 464
    i64.add
    local.get 5
    i64.const 0
    i64.const -4294967297
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 448
    i64.add
    local.get 5
    i64.const 0
    i64.const 4294967295
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 256
    i64.add
    local.get 2
    i64.load offset=8
    local.tee 6
    i64.const 0
    i64.const 85565669623438334
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 272
    i64.add
    local.get 6
    i64.const 0
    i64.const 4834901528447446049
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 288
    i64.add
    local.get 6
    i64.const 0
    i64.const -4294967297
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 304
    i64.add
    local.get 6
    i64.const 0
    i64.const 4294967295
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 320
    i64.add
    local.get 2
    i64.load offset=16
    local.tee 7
    i64.const 0
    i64.const 85565669623438334
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 336
    i64.add
    local.get 7
    i64.const 0
    i64.const 4834901528447446049
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 352
    i64.add
    local.get 7
    i64.const 0
    i64.const -4294967297
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 368
    i64.add
    local.get 7
    i64.const 0
    i64.const 4294967295
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 384
    i64.add
    local.get 2
    i64.load offset=24
    local.tee 2
    i64.const 0
    i64.const 85565669623438334
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 400
    i64.add
    local.get 2
    i64.const 0
    i64.const 4834901528447446049
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 416
    i64.add
    local.get 2
    i64.const 0
    i64.const -4294967297
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 432
    i64.add
    local.get 2
    i64.const 0
    i64.const 4294967295
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 48
    i64.add
    local.get 5
    local.get 4
    local.get 3
    i64.load offset=248
    local.get 3
    i64.load offset=232
    local.get 3
    i64.load offset=216
    local.get 3
    i64.load offset=200
    local.tee 8
    local.get 3
    i64.load offset=208
    i64.add
    local.tee 9
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    local.get 3
    i64.load offset=224
    i64.add
    local.tee 8
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 11
    local.get 3
    i64.load offset=240
    i64.add
    local.tee 10
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 12
    i64.add
    local.tee 11
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    local.tee 13
    i64.add
    local.tee 12
    local.get 3
    i64.load offset=456
    local.get 11
    local.get 3
    i64.load offset=448
    i64.add
    local.tee 14
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 14
    local.get 3
    i64.load offset=472
    local.get 10
    local.get 3
    i64.load offset=464
    i64.add
    local.tee 11
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 11
    local.get 3
    i64.load offset=488
    local.get 8
    local.get 3
    i64.load offset=480
    i64.add
    local.tee 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 10
    local.get 3
    i64.load offset=504
    local.get 9
    i64.const -2
    i64.and
    local.tee 8
    local.get 3
    i64.load offset=496
    i64.add
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 15
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 8
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 11
    local.get 3
    i64.load offset=304
    i64.add
    local.tee 14
    local.get 3
    i64.load offset=296
    local.get 10
    local.get 3
    i64.load offset=288
    i64.add
    local.tee 9
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 9
    local.get 3
    i64.load offset=280
    local.get 8
    local.get 3
    i64.load offset=272
    i64.add
    local.tee 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 10
    local.get 3
    i64.load offset=264
    local.get 15
    i64.const -2
    i64.and
    local.tee 8
    local.get 3
    i64.load offset=256
    i64.add
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 16
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 8
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    local.get 3
    i64.load offset=352
    i64.add
    local.tee 9
    local.get 3
    i64.load offset=344
    local.get 8
    local.get 3
    i64.load offset=336
    i64.add
    local.tee 15
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 15
    local.get 3
    i64.load offset=328
    local.get 16
    i64.const -2
    i64.and
    local.tee 8
    local.get 3
    i64.load offset=320
    i64.add
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 8
    local.get 15
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 15
    local.get 3
    i64.load offset=400
    i64.add
    local.tee 16
    local.get 3
    i64.load offset=392
    local.get 8
    i64.const -2
    i64.and
    local.tee 8
    local.get 3
    i64.load offset=384
    i64.add
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 8
    i64.const 0
    i64.const -884452912994769583
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 32
    i64.add
    local.get 8
    i64.const 0
    i64.const -4834901526196019580
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 16
    i64.add
    local.get 8
    i64.const 0
    i64.const -1
    i64.const 0
    call $__multi3
    local.get 3
    local.get 8
    i64.const 0
    i64.const -4294967296
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 96
    i64.add
    local.get 6
    local.get 12
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    local.get 11
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 13
    i64.add
    local.tee 12
    local.get 3
    i64.load offset=312
    local.get 14
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 10
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 11
    local.get 3
    i64.load offset=368
    i64.add
    local.tee 14
    local.get 3
    i64.load offset=360
    local.get 9
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 15
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    local.get 3
    i64.load offset=416
    i64.add
    local.tee 9
    local.get 3
    i64.load offset=408
    local.get 16
    local.get 15
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 8
    local.get 16
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 6
    i64.const 0
    i64.const -884452912994769583
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 80
    i64.add
    local.get 6
    i64.const 0
    i64.const -4834901526196019580
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 64
    i64.add
    local.get 6
    i64.const 0
    i64.const -1
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 128
    i64.add
    local.get 7
    local.get 12
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    local.get 11
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 15
    i64.add
    local.tee 8
    local.get 3
    i64.load offset=376
    local.get 14
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 10
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 11
    local.get 3
    i64.load offset=432
    i64.add
    local.tee 12
    local.get 3
    i64.load offset=424
    local.get 9
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 6
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 7
    i64.const 0
    i64.const -884452912994769583
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 112
    i64.add
    local.get 7
    i64.const 0
    i64.const -4834901526196019580
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 160
    i64.add
    local.get 2
    local.get 8
    local.get 15
    i64.lt_u
    i64.extend_i32_u
    local.get 11
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    i64.add
    local.tee 2
    local.get 3
    i64.load offset=440
    local.get 12
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 7
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 8
    i64.const 0
    i64.const -884452912994769583
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 144
    i64.add
    local.get 8
    local.get 2
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    local.get 8
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 2
    i64.const 4834901526196019580
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 176
    i64.add
    local.get 2
    i64.const 0
    i64.const 884452912994769583
    i64.const 0
    call $__multi3
    local.get 0
    local.get 1
    i64.load
    local.tee 11
    local.get 3
    i64.load offset=48
    local.tee 12
    i64.sub
    local.tee 2
    i64.const 884452912994769583
    i64.add
    local.tee 15
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 2
    local.get 2
    local.get 1
    i64.load offset=8
    local.tee 14
    local.get 3
    i64.load offset=56
    local.tee 9
    local.get 3
    i64.load offset=32
    i64.add
    local.tee 8
    local.get 3
    i64.load offset=96
    i64.add
    local.tee 10
    i64.sub
    local.tee 16
    local.get 11
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    local.tee 13
    i64.sub
    local.tee 17
    i64.add
    local.tee 11
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 11
    i64.const 4834901526196019580
    i64.add
    local.tee 18
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 2
    local.get 2
    local.get 1
    i64.load offset=16
    local.tee 19
    local.get 3
    i64.load offset=40
    local.get 8
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 9
    local.get 3
    i64.load offset=16
    i64.add
    local.tee 1
    local.get 3
    i64.load offset=80
    i64.add
    local.tee 11
    local.get 3
    i64.load offset=104
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 8
    local.get 3
    i64.load offset=128
    i64.add
    local.tee 12
    i64.sub
    local.tee 20
    local.get 17
    local.get 16
    i64.lt_u
    i64.extend_i32_u
    local.get 13
    local.get 14
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.sub
    i64.const 63
    i64.shr_s
    local.tee 16
    i64.add
    local.tee 13
    i64.add
    local.tee 10
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 10
    i64.const 1
    i64.add
    local.tee 17
    i64.eqz
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 2
    local.get 2
    local.get 4
    local.get 3
    i64.load offset=24
    local.get 1
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 21
    local.get 3
    i64.load
    i64.add
    local.tee 10
    local.get 3
    i64.load offset=64
    i64.add
    local.tee 14
    local.get 3
    i64.load offset=88
    local.get 11
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 8
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 1
    local.get 3
    i64.load offset=112
    i64.add
    local.tee 11
    local.get 3
    i64.load offset=136
    local.get 12
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 8
    local.get 3
    i64.load offset=160
    i64.add
    local.tee 9
    i64.sub
    local.tee 22
    local.get 16
    local.get 19
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 13
    local.get 20
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 16
    i64.add
    local.tee 13
    i64.add
    local.tee 12
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 12
    i64.const 4294967296
    i64.add
    local.tee 19
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 2
    local.get 2
    local.get 5
    local.get 6
    i64.const 32
    i64.shl
    local.get 7
    i64.add
    local.get 3
    i64.load offset=144
    i64.add
    local.get 3
    i64.load offset=176
    i64.add
    local.get 3
    i64.load offset=8
    local.get 10
    local.get 21
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 3
    i64.load offset=72
    local.get 14
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 1
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 3
    i64.load offset=120
    local.get 11
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 8
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 3
    i64.load offset=168
    local.get 9
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    i64.sub
    i64.add
    local.get 16
    local.get 4
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 13
    local.get 22
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    i64.add
    i64.add
    local.tee 6
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 4
    i64.const -884452912994769583
    i64.and
    local.tee 2
    local.get 15
    i64.add
    local.tee 5
    i64.const 884452912994769583
    i64.add
    local.tee 7
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 8
    local.get 8
    local.get 4
    i64.const -4834901526196019580
    i64.and
    local.tee 10
    local.get 18
    i64.add
    local.tee 1
    local.get 5
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    i64.add
    local.tee 2
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 2
    i64.const 4834901526196019580
    i64.add
    local.tee 8
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 11
    local.get 11
    local.get 4
    local.get 17
    i64.add
    local.tee 2
    local.get 1
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 5
    i64.add
    local.tee 1
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 1
    i64.const 1
    i64.add
    local.tee 10
    i64.eqz
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 11
    local.get 11
    local.get 4
    i64.const -4294967296
    i64.and
    local.tee 12
    local.get 19
    i64.add
    local.tee 1
    local.get 2
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 4
    i64.add
    local.tee 5
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const 4294967296
    i64.add
    local.tee 2
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 5
    local.get 1
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    local.get 4
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 6
    i64.add
    i64.add
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 4
    i64.const -884452912994769583
    i64.and
    local.tee 1
    local.get 7
    i64.add
    local.tee 6
    i64.store
    local.get 0
    local.get 4
    i64.const -4834901526196019580
    i64.and
    local.tee 7
    local.get 8
    i64.add
    local.tee 5
    local.get 6
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.store offset=8
    local.get 0
    local.get 4
    local.get 10
    i64.add
    local.tee 1
    local.get 5
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    local.get 6
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 5
    i64.store offset=16
    local.get 0
    local.get 4
    i64.const -4294967296
    i64.and
    local.get 2
    i64.add
    local.get 1
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    i64.store offset=24
    local.get 3
    i64.const 512
    i64.add
    global.set $__stack_pointer)
