  (func $_RNvMNtNtCs8m9hhMswt4C_4p25610arithmetic6scalarNtB2_6Scalar8multiply (type 1) (param i64 i64 i64)
    (local i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    global.get $__stack_pointer
    i64.const 320
    i64.sub
    local.tee 3
    global.set $__stack_pointer
    local.get 3
    local.get 2
    i64.load
    local.tee 4
    i64.const 0
    local.get 1
    i64.load
    local.tee 5
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 64
    i64.add
    local.get 2
    i64.load offset=8
    local.tee 6
    i64.const 0
    local.get 5
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 80
    i64.add
    local.get 2
    i64.load offset=16
    local.tee 7
    i64.const 0
    local.get 5
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 96
    i64.add
    local.get 2
    i64.load offset=24
    local.tee 2
    i64.const 0
    local.get 5
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 16
    i64.add
    local.get 1
    i64.load offset=8
    local.tee 5
    i64.const 0
    local.get 4
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 112
    i64.add
    local.get 5
    i64.const 0
    local.get 6
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 160
    i64.add
    local.get 5
    i64.const 0
    local.get 7
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 208
    i64.add
    local.get 5
    i64.const 0
    local.get 2
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 32
    i64.add
    local.get 1
    i64.load offset=16
    local.tee 5
    i64.const 0
    local.get 4
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 128
    i64.add
    local.get 5
    i64.const 0
    local.get 6
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 176
    i64.add
    local.get 5
    i64.const 0
    local.get 7
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 224
    i64.add
    local.get 5
    i64.const 0
    local.get 2
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 48
    i64.add
    local.get 1
    i64.load offset=24
    local.tee 1
    i64.const 0
    local.get 4
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 144
    i64.add
    local.get 1
    i64.const 0
    local.get 6
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 192
    i64.add
    local.get 1
    i64.const 0
    local.get 7
    i64.const 0
    call $__multi3
    local.get 3
    i64.const 240
    i64.add
    local.get 1
    i64.const 0
    local.get 2
    i64.const 0
    call $__multi3
    local.get 3
    local.get 3
    i64.load
    i64.store offset=256
    local.get 3
    i64.load offset=72
    local.set 1
    local.get 3
    i64.load offset=80
    local.set 2
    local.get 3
    i64.load offset=112
    local.set 4
    local.get 3
    i64.load offset=120
    local.set 8
    local.get 3
    local.get 3
    i64.load offset=16
    local.tee 5
    local.get 3
    i64.load offset=8
    local.tee 6
    local.get 3
    i64.load offset=64
    i64.add
    local.tee 7
    i64.add
    local.tee 9
    i64.store offset=264
    local.get 3
    i64.load offset=88
    local.set 10
    local.get 3
    i64.load offset=96
    local.set 11
    local.get 3
    i64.load offset=160
    local.set 12
    local.get 3
    local.get 4
    local.get 2
    local.get 1
    local.get 7
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.add
    local.tee 1
    i64.add
    local.tee 2
    local.get 3
    i64.load offset=24
    local.get 9
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 4
    local.get 3
    i64.load offset=32
    i64.add
    local.tee 5
    i64.store offset=272
    local.get 3
    local.get 3
    i64.load offset=40
    local.get 5
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 9
    local.get 3
    i64.load offset=128
    i64.add
    local.tee 5
    local.get 12
    local.get 11
    local.get 10
    local.get 1
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    i64.add
    local.tee 6
    i64.add
    local.tee 7
    local.get 8
    local.get 2
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 4
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 8
    i64.add
    local.tee 1
    local.get 3
    i64.load offset=48
    i64.add
    local.tee 2
    i64.store offset=280
    local.get 3
    i64.load offset=152
    local.set 11
    local.get 3
    local.get 3
    i64.load offset=56
    local.get 2
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 12
    local.get 3
    i64.load offset=144
    i64.add
    local.tee 2
    local.get 3
    i64.load offset=136
    local.get 5
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 1
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    local.get 3
    i64.load offset=176
    i64.add
    local.tee 1
    local.get 3
    i64.load offset=104
    local.get 6
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 9
    local.get 3
    i64.load offset=208
    i64.add
    local.tee 4
    local.get 3
    i64.load offset=168
    local.get 7
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 8
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 6
    i64.add
    local.tee 7
    i64.add
    local.tee 8
    i64.store offset=288
    local.get 3
    i64.load offset=200
    local.set 10
    local.get 3
    local.get 11
    local.get 2
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 8
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    local.get 3
    i64.load offset=192
    i64.add
    local.tee 2
    local.get 3
    i64.load offset=216
    local.get 4
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 6
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    local.get 3
    i64.load offset=224
    i64.add
    local.tee 4
    local.get 3
    i64.load offset=184
    local.get 1
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 7
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 1
    i64.add
    local.tee 5
    i64.store offset=296
    local.get 3
    local.get 3
    i64.load offset=232
    local.get 4
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 1
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 4
    local.get 3
    i64.load offset=240
    i64.add
    local.tee 1
    local.get 10
    local.get 2
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 2
    i64.store offset=304
    local.get 3
    local.get 3
    i64.load offset=248
    local.get 1
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 2
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.store offset=312
    local.get 0
    local.get 3
    i64.const 256
    i64.add
    local.get 3
    i64.const 288
    i64.add
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic6scalar11scalar_impl14barrett_reduce
    local.get 3
    i64.const 320
    i64.add
    global.set $__stack_pointer)
