  (func $_RNvXs_NtCsjGjB7j23zne_10primeorder16point_arithmeticNtB4_21EquationAIsMinusThreeINtNtB4_6sealed15PointArithmeticNtCs8m9hhMswt4C_4p2568NistP256E9add_mixedCsakw9nm40atj_19motoko_compute_p256 (type 1) (param i64 i64 i64)
    (local i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64)
    global.get $__stack_pointer
    i64.const 352
    i64.sub
    local.tee 3
    global.set $__stack_pointer
    local.get 3
    local.get 1
    local.get 2
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    i64.const 32
    i64.add
    local.get 1
    i64.const 32
    i64.add
    local.get 2
    i64.const 32
    i64.add
    local.tee 4
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    local.get 1
    i64.load offset=32
    local.tee 5
    local.get 1
    i64.load
    i64.add
    local.tee 6
    i64.const 1
    i64.add
    local.tee 7
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 8
    local.get 8
    local.get 1
    i64.load offset=40
    local.tee 9
    local.get 1
    i64.load offset=8
    i64.add
    local.tee 10
    local.get 6
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.add
    local.tee 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const -4294967295
    i64.add
    local.tee 11
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 8
    local.get 8
    local.get 1
    i64.load offset=48
    local.tee 12
    local.get 1
    i64.load offset=16
    i64.add
    local.tee 5
    local.get 10
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    local.get 6
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 6
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 9
    local.get 9
    local.get 1
    i64.load offset=56
    local.tee 13
    local.get 1
    i64.load offset=24
    i64.add
    local.tee 8
    local.get 5
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const 4294967295
    i64.add
    local.tee 9
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 5
    local.get 8
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    local.get 7
    i64.add
    local.tee 5
    i64.store offset=288
    local.get 3
    local.get 8
    i64.const 4294967295
    i64.and
    local.tee 7
    local.get 11
    i64.add
    local.tee 10
    local.get 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    i64.store offset=296
    local.get 3
    local.get 10
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    local.get 6
    i64.add
    local.tee 5
    i64.store offset=304
    local.get 3
    local.get 8
    i64.const -4294967295
    i64.and
    local.get 9
    i64.add
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.store offset=312
    local.get 3
    local.get 2
    i64.load offset=32
    local.tee 5
    local.get 2
    i64.load
    i64.add
    local.tee 6
    i64.const 1
    i64.add
    local.tee 7
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 8
    local.get 8
    local.get 2
    i64.load offset=40
    local.tee 9
    local.get 2
    i64.load offset=8
    i64.add
    local.tee 10
    local.get 6
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.add
    local.tee 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const -4294967295
    i64.add
    local.tee 11
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 8
    local.get 8
    local.get 2
    i64.load offset=48
    local.tee 12
    local.get 2
    i64.load offset=16
    i64.add
    local.tee 5
    local.get 10
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    local.get 6
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 6
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 9
    local.get 9
    local.get 2
    i64.load offset=56
    local.tee 13
    local.get 2
    i64.load offset=24
    i64.add
    local.tee 8
    local.get 5
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const 4294967295
    i64.add
    local.tee 9
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 5
    local.get 8
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    local.get 7
    i64.add
    local.tee 5
    i64.store offset=320
    local.get 3
    local.get 8
    i64.const 4294967295
    i64.and
    local.tee 7
    local.get 11
    i64.add
    local.tee 10
    local.get 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    i64.store offset=328
    local.get 3
    local.get 10
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    local.get 6
    i64.add
    local.tee 5
    i64.store offset=336
    local.get 3
    local.get 8
    i64.const -4294967295
    i64.and
    local.get 9
    i64.add
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.store offset=344
    local.get 3
    i64.const 128
    i64.add
    local.get 3
    i64.const 288
    i64.add
    local.get 3
    i64.const 320
    i64.add
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    local.get 3
    i64.load offset=136
    local.tee 7
    local.get 3
    i64.load offset=32
    local.tee 5
    local.get 3
    i64.load
    i64.add
    local.tee 6
    i64.const 1
    i64.add
    local.tee 9
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 8
    local.get 8
    local.get 3
    i64.load offset=40
    local.tee 11
    local.get 3
    i64.load offset=8
    i64.add
    local.tee 10
    local.get 6
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.add
    local.tee 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const -4294967295
    i64.add
    local.tee 12
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 8
    local.get 8
    local.get 3
    i64.load offset=48
    local.tee 13
    local.get 3
    i64.load offset=16
    i64.add
    local.tee 5
    local.get 10
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    local.get 6
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 11
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    local.get 6
    local.get 3
    i64.load offset=56
    local.tee 14
    local.get 3
    i64.load offset=24
    i64.add
    local.tee 8
    local.get 5
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const 4294967295
    i64.add
    local.tee 13
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 5
    local.get 8
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    i64.const 4294967295
    i64.and
    local.tee 14
    local.get 12
    i64.add
    local.tee 10
    local.get 8
    local.get 9
    i64.add
    local.tee 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.sub
    local.tee 9
    local.get 3
    i64.load offset=128
    local.tee 12
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    local.tee 15
    i64.sub
    local.tee 16
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    local.get 15
    local.get 7
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.sub
    i64.const 63
    i64.shr_s
    local.tee 7
    local.get 3
    i64.load offset=144
    local.tee 9
    local.get 10
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    local.get 6
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 14
    local.get 11
    i64.add
    local.tee 10
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 7
    local.get 9
    local.get 10
    i64.sub
    i64.add
    local.tee 9
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    local.get 3
    i64.load offset=152
    local.tee 7
    local.get 8
    i64.const -4294967295
    i64.and
    local.get 13
    i64.add
    local.get 10
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 6
    local.get 7
    local.get 8
    i64.sub
    i64.add
    local.tee 7
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 8
    local.get 12
    local.get 5
    i64.sub
    i64.add
    local.tee 5
    i64.store offset=64
    local.get 3
    local.get 8
    i64.const 4294967295
    i64.and
    local.tee 6
    local.get 16
    i64.add
    local.tee 10
    local.get 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    i64.store offset=72
    local.get 3
    local.get 10
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    local.get 9
    i64.add
    local.tee 5
    i64.store offset=80
    local.get 3
    local.get 8
    i64.const -4294967295
    i64.and
    local.get 7
    i64.add
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.store offset=88
    local.get 3
    i64.const 320
    i64.add
    local.get 4
    local.get 1
    i64.const 64
    i64.add
    local.tee 7
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    local.get 1
    i64.load offset=32
    local.tee 5
    local.get 3
    i64.load offset=320
    i64.add
    local.tee 6
    i64.const 1
    i64.add
    local.tee 4
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 8
    local.get 8
    local.get 1
    i64.load offset=40
    local.tee 9
    local.get 3
    i64.load offset=328
    i64.add
    local.tee 10
    local.get 6
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.add
    local.tee 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const -4294967295
    i64.add
    local.tee 11
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 8
    local.get 8
    local.get 1
    i64.load offset=48
    local.tee 12
    local.get 3
    i64.load offset=336
    i64.add
    local.tee 5
    local.get 10
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    local.get 6
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 6
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 9
    local.get 9
    local.get 1
    i64.load offset=56
    local.tee 13
    local.get 3
    i64.load offset=344
    i64.add
    local.tee 8
    local.get 5
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const 4294967295
    i64.add
    local.tee 9
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 5
    local.get 8
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    local.get 4
    i64.add
    local.tee 5
    i64.store offset=96
    local.get 3
    local.get 8
    i64.const 4294967295
    i64.and
    local.tee 4
    local.get 11
    i64.add
    local.tee 10
    local.get 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    i64.store offset=104
    local.get 3
    local.get 10
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    local.get 6
    i64.add
    local.tee 5
    i64.store offset=112
    local.get 3
    local.get 8
    i64.const -4294967295
    i64.and
    local.get 9
    i64.add
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.store offset=120
    local.get 3
    i64.const 320
    i64.add
    local.get 2
    local.get 7
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    local.get 1
    i64.load
    local.tee 5
    local.get 3
    i64.load offset=320
    i64.add
    local.tee 6
    i64.const 1
    i64.add
    local.tee 4
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 8
    local.get 8
    local.get 1
    i64.load offset=8
    local.tee 9
    local.get 3
    i64.load offset=328
    i64.add
    local.tee 10
    local.get 6
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.add
    local.tee 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const -4294967295
    i64.add
    local.tee 11
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 8
    local.get 8
    local.get 1
    i64.load offset=16
    local.tee 12
    local.get 3
    i64.load offset=336
    i64.add
    local.tee 5
    local.get 10
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    local.get 6
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 9
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    local.get 6
    local.get 1
    i64.load offset=24
    local.tee 13
    local.get 3
    i64.load offset=344
    i64.add
    local.tee 8
    local.get 5
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const 4294967295
    i64.add
    local.tee 12
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 5
    local.get 8
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    local.get 4
    i64.add
    local.tee 10
    i64.store offset=128
    local.get 3
    local.get 8
    i64.const 4294967295
    i64.and
    local.tee 4
    local.get 11
    i64.add
    local.tee 6
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    i64.store offset=136
    local.get 3
    local.get 6
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 4
    local.get 9
    i64.add
    local.tee 6
    i64.store offset=144
    local.get 3
    local.get 8
    i64.const -4294967295
    i64.and
    local.get 12
    i64.add
    local.get 6
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    i64.store offset=152
    local.get 3
    i64.const 320
    i64.add
    global.get $__memory_base
    i64.const 136
    i64.add
    local.tee 14
    local.get 7
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    local.get 3
    i64.load offset=40
    local.tee 9
    local.get 5
    local.get 3
    i64.load offset=328
    local.tee 7
    i64.sub
    local.tee 4
    local.get 10
    local.get 3
    i64.load offset=320
    local.tee 11
    i64.lt_u
    i64.extend_i32_u
    local.tee 12
    i64.sub
    local.tee 13
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    local.get 12
    local.get 5
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.sub
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 6
    local.get 3
    i64.load offset=336
    local.tee 7
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 5
    local.get 6
    local.get 7
    i64.sub
    i64.add
    local.tee 4
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 8
    local.get 3
    i64.load offset=344
    local.tee 6
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 5
    local.get 8
    local.get 6
    i64.sub
    i64.add
    local.tee 12
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    local.get 10
    local.get 11
    i64.sub
    i64.add
    local.tee 8
    local.get 6
    i64.const 4294967295
    i64.and
    local.tee 11
    local.get 13
    i64.add
    local.tee 5
    local.get 8
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    i64.const 1
    i64.shl
    local.get 8
    i64.const 63
    i64.shr_u
    i64.or
    local.tee 7
    i64.const -4294967296
    i64.add
    local.tee 13
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 7
    local.get 7
    local.get 5
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 11
    local.get 4
    i64.add
    local.tee 5
    i64.const 1
    i64.shl
    local.get 10
    i64.const 63
    i64.shr_u
    i64.or
    i64.add
    local.tee 15
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 7
    local.get 7
    local.get 6
    i64.const -4294967295
    i64.and
    local.get 12
    i64.add
    local.get 5
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.const 1
    i64.shl
    local.get 5
    i64.const 63
    i64.shr_u
    i64.or
    local.tee 4
    i64.add
    local.tee 7
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 7
    i64.const 4294967295
    i64.add
    local.tee 16
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 7
    local.get 7
    local.get 6
    i64.const 63
    i64.shr_u
    i64.add
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 7
    local.get 8
    i64.const 1
    i64.shl
    i64.add
    i64.const 1
    i64.add
    local.tee 12
    i64.add
    local.tee 17
    i64.const 1
    i64.add
    local.tee 18
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 4
    local.get 4
    local.get 10
    local.get 7
    i64.const 4294967295
    i64.and
    local.tee 19
    local.get 13
    i64.add
    local.tee 11
    local.get 12
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 13
    i64.add
    local.tee 12
    local.get 17
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 17
    i64.add
    local.tee 8
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 8
    i64.const -4294967295
    i64.add
    local.tee 20
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 8
    local.get 8
    local.get 5
    local.get 11
    local.get 19
    i64.lt_u
    i64.extend_i32_u
    local.get 13
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 11
    local.get 15
    i64.add
    local.tee 13
    i64.add
    local.tee 4
    local.get 12
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    local.get 17
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 12
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 15
    local.get 15
    local.get 6
    local.get 7
    i64.const -4294967295
    i64.and
    local.get 16
    i64.add
    local.get 13
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 8
    local.get 4
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const 4294967295
    i64.add
    local.tee 13
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 5
    local.get 8
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    i64.const 4294967295
    i64.and
    local.tee 15
    local.get 20
    i64.add
    local.tee 10
    local.get 5
    local.get 18
    i64.add
    local.tee 6
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    i64.sub
    local.tee 4
    local.get 3
    i64.load offset=32
    local.tee 7
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    local.tee 11
    i64.sub
    local.tee 16
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    local.get 11
    local.get 9
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.sub
    i64.const 63
    i64.shr_s
    local.tee 4
    local.get 3
    i64.load offset=48
    local.tee 11
    local.get 10
    local.get 15
    i64.lt_u
    i64.extend_i32_u
    local.get 8
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 15
    local.get 12
    i64.add
    local.tee 10
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 4
    local.get 11
    local.get 10
    i64.sub
    i64.add
    local.tee 17
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 4
    local.get 3
    i64.load offset=56
    local.tee 12
    local.get 5
    i64.const -4294967295
    i64.and
    local.get 13
    i64.add
    local.get 10
    local.get 15
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 4
    local.get 12
    local.get 5
    i64.sub
    i64.add
    local.tee 15
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 4
    local.get 7
    local.get 6
    i64.sub
    i64.add
    local.tee 18
    i64.store offset=160
    local.get 3
    local.get 4
    i64.const 4294967295
    i64.and
    local.tee 19
    local.get 16
    i64.add
    local.tee 13
    local.get 18
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 16
    i64.store offset=168
    local.get 3
    local.get 13
    local.get 19
    i64.lt_u
    i64.extend_i32_u
    local.get 16
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 13
    local.get 17
    i64.add
    local.tee 16
    i64.store offset=176
    local.get 3
    local.get 4
    i64.const -4294967295
    i64.and
    local.get 15
    i64.add
    local.get 16
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.store offset=184
    local.get 3
    local.get 7
    local.get 6
    i64.add
    local.tee 13
    i64.const 1
    i64.add
    local.tee 15
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 6
    local.get 6
    local.get 8
    local.get 9
    i64.add
    local.tee 4
    local.get 13
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 9
    i64.add
    local.tee 7
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 7
    i64.const -4294967295
    i64.add
    local.tee 13
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    local.get 6
    local.get 10
    local.get 11
    i64.add
    local.tee 7
    local.get 4
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    local.get 9
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 4
    i64.add
    local.tee 9
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    local.get 6
    local.get 5
    local.get 12
    i64.add
    local.tee 8
    local.get 7
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    local.get 4
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 6
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 6
    i64.const 4294967295
    i64.add
    local.tee 7
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    local.get 6
    local.get 8
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    local.get 15
    i64.add
    local.tee 5
    i64.store offset=192
    local.get 3
    local.get 8
    i64.const 4294967295
    i64.and
    local.tee 6
    local.get 13
    i64.add
    local.tee 10
    local.get 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    i64.store offset=200
    local.get 3
    local.get 10
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    local.get 9
    i64.add
    local.tee 5
    i64.store offset=208
    local.get 3
    local.get 8
    i64.const -4294967295
    i64.and
    local.get 7
    i64.add
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.store offset=216
    local.get 1
    i64.load offset=88
    local.set 5
    local.get 1
    i64.load offset=80
    local.set 6
    local.get 1
    i64.load offset=72
    local.set 7
    local.get 1
    i64.load offset=64
    local.set 10
    local.get 3
    i64.const 320
    i64.add
    local.get 14
    local.get 3
    i64.const 128
    i64.add
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    local.get 3
    i64.load
    local.tee 8
    local.get 3
    i64.load offset=8
    local.tee 4
    i64.const 1
    i64.shl
    local.get 8
    i64.const 63
    i64.shr_u
    i64.or
    local.tee 9
    i64.const -4294967296
    i64.add
    local.tee 14
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 11
    local.get 11
    local.get 3
    i64.load offset=16
    local.tee 9
    i64.const 1
    i64.shl
    local.get 4
    i64.const 63
    i64.shr_u
    i64.or
    i64.add
    local.tee 18
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 12
    local.get 12
    local.get 3
    i64.load offset=24
    local.tee 11
    i64.const 1
    i64.shl
    local.get 9
    i64.const 63
    i64.shr_u
    i64.or
    local.tee 13
    i64.add
    local.tee 12
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 12
    i64.const 4294967295
    i64.add
    local.tee 19
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 12
    local.get 12
    local.get 11
    i64.const 63
    i64.shr_u
    i64.add
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 12
    local.get 8
    i64.const 1
    i64.shl
    i64.add
    i64.const 1
    i64.add
    local.tee 15
    i64.add
    local.tee 17
    i64.const 1
    i64.add
    local.tee 20
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 13
    local.get 13
    local.get 12
    i64.const 4294967295
    i64.and
    local.tee 21
    local.get 14
    i64.add
    local.tee 14
    local.get 15
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 15
    local.get 4
    i64.add
    local.tee 16
    local.get 17
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 22
    i64.add
    local.tee 17
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 17
    i64.const -4294967295
    i64.add
    local.tee 23
    local.get 17
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 13
    local.get 13
    local.get 14
    local.get 21
    i64.lt_u
    i64.extend_i32_u
    local.get 15
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 21
    local.get 18
    i64.add
    local.tee 14
    local.get 9
    i64.add
    local.tee 17
    local.get 16
    local.get 15
    i64.lt_u
    i64.extend_i32_u
    local.get 22
    local.get 16
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 15
    i64.add
    local.tee 22
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 16
    local.get 16
    local.get 12
    i64.const -4294967295
    i64.and
    local.get 19
    i64.add
    local.get 14
    local.get 21
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 18
    local.get 11
    i64.add
    local.tee 12
    local.get 17
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    local.get 15
    local.get 17
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 13
    i64.add
    local.tee 14
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 14
    i64.const 4294967295
    i64.add
    local.tee 21
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 14
    local.get 14
    local.get 12
    local.get 18
    i64.lt_u
    i64.extend_i32_u
    local.get 13
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 12
    i64.const 4294967295
    i64.and
    local.tee 24
    local.get 23
    i64.add
    local.tee 14
    local.get 12
    local.get 20
    i64.add
    local.tee 15
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 16
    local.get 10
    local.get 7
    i64.const 1
    i64.shl
    local.get 10
    i64.const 63
    i64.shr_u
    i64.or
    local.tee 13
    i64.const -4294967296
    i64.add
    local.tee 18
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 13
    local.get 13
    local.get 6
    i64.const 1
    i64.shl
    local.get 7
    i64.const 63
    i64.shr_u
    i64.or
    i64.add
    local.tee 20
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 13
    local.get 13
    local.get 5
    i64.const 1
    i64.shl
    local.get 6
    i64.const 63
    i64.shr_u
    i64.or
    local.tee 17
    i64.add
    local.tee 13
    local.get 17
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 13
    i64.const 4294967295
    i64.add
    local.tee 23
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 13
    local.get 13
    local.get 5
    i64.const 63
    i64.shr_u
    i64.add
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 13
    local.get 10
    i64.const 1
    i64.shl
    i64.add
    i64.const 1
    i64.add
    local.tee 19
    i64.add
    local.tee 25
    i64.const 1
    i64.add
    local.tee 26
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 17
    local.get 17
    local.get 7
    local.get 13
    i64.const 4294967295
    i64.and
    local.tee 27
    local.get 18
    i64.add
    local.tee 18
    local.get 19
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 19
    i64.add
    local.tee 7
    local.get 25
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 25
    i64.add
    local.tee 10
    local.get 17
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 10
    i64.const -4294967295
    i64.add
    local.tee 28
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 10
    local.get 10
    local.get 6
    local.get 18
    local.get 27
    i64.lt_u
    i64.extend_i32_u
    local.get 19
    local.get 18
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 18
    local.get 20
    i64.add
    local.tee 17
    i64.add
    local.tee 6
    local.get 7
    local.get 19
    i64.lt_u
    i64.extend_i32_u
    local.get 25
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 7
    i64.add
    local.tee 19
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 20
    local.get 20
    local.get 5
    local.get 13
    i64.const -4294967295
    i64.and
    local.get 23
    i64.add
    local.get 17
    local.get 18
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 13
    i64.add
    local.tee 10
    local.get 6
    local.get 17
    i64.lt_u
    i64.extend_i32_u
    local.get 7
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 5
    i64.add
    local.tee 6
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 6
    i64.const 4294967295
    i64.add
    local.tee 17
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    local.get 6
    local.get 10
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.const 4294967295
    i64.and
    local.tee 18
    local.get 28
    i64.add
    local.tee 5
    local.get 6
    local.get 26
    i64.add
    local.tee 7
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    i64.sub
    local.tee 13
    local.get 15
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    local.tee 20
    i64.sub
    local.tee 23
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    local.get 20
    local.get 16
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.sub
    i64.const 63
    i64.shr_s
    local.tee 13
    local.get 14
    local.get 24
    i64.lt_u
    i64.extend_i32_u
    local.get 16
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 16
    local.get 22
    i64.add
    local.tee 14
    local.get 5
    local.get 18
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 18
    local.get 19
    i64.add
    local.tee 5
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 13
    local.get 14
    local.get 5
    i64.sub
    i64.add
    local.tee 19
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 13
    local.get 12
    i64.const -4294967295
    i64.and
    local.get 21
    i64.add
    local.get 14
    local.get 16
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 12
    local.get 6
    i64.const -4294967295
    i64.and
    local.get 17
    i64.add
    local.get 5
    local.get 18
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 13
    local.get 12
    local.get 6
    i64.sub
    i64.add
    local.tee 14
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 12
    local.get 15
    local.get 7
    i64.sub
    i64.add
    local.tee 15
    i64.store offset=256
    local.get 3
    local.get 12
    i64.const 4294967295
    i64.and
    local.tee 16
    local.get 23
    i64.add
    local.tee 13
    local.get 15
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 15
    i64.store offset=264
    local.get 3
    local.get 13
    local.get 16
    i64.lt_u
    i64.extend_i32_u
    local.get 15
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 13
    local.get 19
    i64.add
    local.tee 15
    i64.store offset=272
    local.get 3
    local.get 12
    i64.const -4294967295
    i64.and
    local.get 14
    i64.add
    local.get 15
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.store offset=280
    local.get 3
    local.get 3
    i64.load offset=328
    local.tee 12
    local.get 8
    local.get 7
    i64.add
    local.tee 13
    i64.const 1
    i64.add
    local.tee 14
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 7
    local.get 7
    local.get 10
    local.get 4
    i64.add
    local.tee 4
    local.get 13
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 13
    i64.add
    local.tee 8
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 8
    i64.const -4294967295
    i64.add
    local.tee 15
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 8
    local.get 8
    local.get 5
    local.get 9
    i64.add
    local.tee 7
    local.get 4
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    local.get 13
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 4
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 9
    local.get 9
    local.get 6
    local.get 11
    i64.add
    local.tee 8
    local.get 7
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const 4294967295
    i64.add
    local.tee 9
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 5
    local.get 8
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    i64.const 4294967295
    i64.and
    local.tee 11
    local.get 15
    i64.add
    local.tee 10
    local.get 8
    local.get 14
    i64.add
    local.tee 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.sub
    local.tee 7
    local.get 3
    i64.load offset=320
    local.tee 13
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    local.tee 14
    i64.sub
    local.tee 15
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    local.get 14
    local.get 12
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.sub
    i64.const 63
    i64.shr_s
    local.tee 7
    local.get 3
    i64.load offset=336
    local.tee 12
    local.get 10
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    local.get 6
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 11
    local.get 4
    i64.add
    local.tee 10
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 7
    local.get 12
    local.get 10
    i64.sub
    i64.add
    local.tee 4
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    local.get 3
    i64.load offset=344
    local.tee 7
    local.get 8
    i64.const -4294967295
    i64.and
    local.get 9
    i64.add
    local.get 10
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 6
    local.get 7
    local.get 8
    i64.sub
    i64.add
    local.tee 9
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    local.get 13
    local.get 5
    i64.sub
    i64.add
    local.tee 8
    local.get 6
    i64.const 4294967295
    i64.and
    local.tee 11
    local.get 15
    i64.add
    local.tee 5
    local.get 8
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    i64.const 1
    i64.shl
    local.get 8
    i64.const 63
    i64.shr_u
    i64.or
    local.tee 7
    i64.const -4294967296
    i64.add
    local.tee 12
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 7
    local.get 7
    local.get 5
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 11
    local.get 4
    i64.add
    local.tee 5
    i64.const 1
    i64.shl
    local.get 10
    i64.const 63
    i64.shr_u
    i64.or
    i64.add
    local.tee 13
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 7
    local.get 7
    local.get 6
    i64.const -4294967295
    i64.and
    local.get 9
    i64.add
    local.get 5
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.const 1
    i64.shl
    local.get 5
    i64.const 63
    i64.shr_u
    i64.or
    local.tee 4
    i64.add
    local.tee 7
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 7
    i64.const 4294967295
    i64.add
    local.tee 14
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 7
    local.get 7
    local.get 6
    i64.const 63
    i64.shr_u
    i64.add
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 7
    local.get 8
    i64.const 1
    i64.shl
    i64.add
    i64.const 1
    i64.add
    local.tee 11
    i64.add
    local.tee 15
    i64.const 1
    i64.add
    local.tee 16
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 4
    local.get 4
    local.get 10
    local.get 7
    i64.const 4294967295
    i64.and
    local.tee 17
    local.get 12
    i64.add
    local.tee 9
    local.get 11
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 12
    i64.add
    local.tee 11
    local.get 15
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 15
    i64.add
    local.tee 8
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 8
    i64.const -4294967295
    i64.add
    local.tee 18
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 8
    local.get 8
    local.get 5
    local.get 9
    local.get 17
    i64.lt_u
    i64.extend_i32_u
    local.get 12
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 9
    local.get 13
    i64.add
    local.tee 12
    i64.add
    local.tee 4
    local.get 11
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    local.get 15
    local.get 11
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 11
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 13
    local.get 13
    local.get 6
    local.get 7
    i64.const -4294967295
    i64.and
    local.get 14
    i64.add
    local.get 12
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 8
    local.get 4
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const 4294967295
    i64.add
    local.tee 7
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 5
    local.get 8
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    local.get 16
    i64.add
    local.tee 5
    i64.store offset=224
    local.get 3
    local.get 8
    i64.const 4294967295
    i64.and
    local.tee 6
    local.get 18
    i64.add
    local.tee 10
    local.get 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    i64.store offset=232
    local.get 3
    local.get 10
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    local.get 11
    i64.add
    local.tee 5
    i64.store offset=240
    local.get 3
    local.get 8
    i64.const -4294967295
    i64.and
    local.get 7
    i64.add
    local.get 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.store offset=248
    local.get 3
    i64.const 288
    i64.add
    local.get 3
    i64.const 192
    i64.add
    local.get 3
    i64.const 64
    i64.add
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    i64.const 320
    i64.add
    local.get 3
    i64.const 96
    i64.add
    local.get 3
    i64.const 224
    i64.add
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    i64.load offset=328
    local.set 8
    local.get 3
    i64.load offset=296
    local.set 10
    local.get 3
    i64.load offset=320
    local.set 5
    local.get 3
    i64.load offset=288
    local.set 6
    local.get 3
    i64.load offset=336
    local.set 7
    local.get 3
    i64.load offset=304
    local.set 4
    local.get 3
    i64.load offset=344
    local.set 9
    local.get 3
    i64.load offset=312
    local.set 11
    local.get 3
    i64.const 288
    i64.add
    local.get 3
    i64.const 192
    i64.add
    local.get 3
    i64.const 160
    i64.add
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    i64.const 320
    i64.add
    local.get 3
    i64.const 256
    i64.add
    local.get 3
    i64.const 224
    i64.add
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    i64.load offset=344
    local.set 12
    local.get 3
    i64.load offset=312
    local.set 20
    local.get 3
    i64.load offset=336
    local.set 13
    local.get 3
    i64.load offset=304
    local.set 21
    local.get 3
    i64.load offset=320
    local.set 14
    local.get 3
    i64.load offset=288
    local.set 22
    local.get 3
    i64.load offset=328
    local.set 15
    local.get 3
    i64.load offset=296
    local.set 23
    local.get 3
    i64.const 288
    i64.add
    local.get 3
    i64.const 160
    i64.add
    local.get 3
    i64.const 96
    i64.add
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    i64.const 320
    i64.add
    local.get 3
    i64.const 64
    i64.add
    local.get 3
    i64.const 256
    i64.add
    call $_RNvNtNtNtCs8m9hhMswt4C_4p25610arithmetic5field10field_impl6fe_mul
    local.get 3
    i64.load offset=344
    local.set 16
    local.get 3
    i64.load offset=312
    local.set 24
    local.get 3
    i64.load offset=336
    local.set 17
    local.get 3
    i64.load offset=304
    local.set 25
    local.get 3
    i64.load offset=320
    local.set 18
    local.get 3
    i64.load offset=288
    local.set 26
    local.get 3
    i64.load offset=328
    local.set 19
    local.get 3
    i64.load offset=296
    local.set 27
    local.get 2
    i32.load8_u offset=64
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    local.set 29
    local.get 0
    local.get 1
    i64.load
    local.get 10
    local.get 8
    i64.sub
    local.tee 2
    local.get 6
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    local.tee 28
    i64.sub
    local.tee 30
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    local.get 28
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.sub
    i64.const 63
    i64.shr_s
    local.tee 2
    local.get 4
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 2
    local.get 4
    local.get 7
    i64.sub
    i64.add
    local.tee 7
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 2
    local.get 11
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.sub
    local.get 2
    local.get 11
    local.get 9
    i64.sub
    i64.add
    local.tee 4
    local.get 2
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 8
    local.get 6
    local.get 5
    i64.sub
    i64.add
    local.tee 10
    i64.xor
    i64.const 0
    local.get 29
    i64.extend_i32_u
    i64.const 255
    i64.and
    i64.sub
    local.tee 2
    i64.and
    local.get 10
    i64.xor
    i64.store
    local.get 0
    local.get 1
    i64.load offset=8
    local.get 8
    i64.const 4294967295
    i64.and
    local.tee 6
    local.get 30
    i64.add
    local.tee 5
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    i64.xor
    local.get 2
    i64.and
    local.get 10
    i64.xor
    i64.store offset=8
    local.get 0
    local.get 1
    i64.load offset=16
    local.get 5
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    local.get 7
    i64.add
    local.tee 10
    i64.xor
    local.get 2
    i64.and
    local.get 10
    i64.xor
    i64.store offset=16
    local.get 0
    local.get 1
    i64.load offset=24
    local.get 8
    i64.const -4294967295
    i64.and
    local.get 4
    i64.add
    local.get 10
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    i64.xor
    local.get 2
    i64.and
    local.get 8
    i64.xor
    i64.store offset=24
    local.get 0
    local.get 1
    i64.load offset=32
    local.get 14
    local.get 22
    i64.add
    local.tee 5
    i64.const 1
    i64.add
    local.tee 6
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 8
    local.get 8
    local.get 15
    local.get 23
    i64.add
    local.tee 10
    local.get 5
    local.get 14
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 7
    i64.add
    local.tee 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const -4294967295
    i64.add
    local.tee 4
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 8
    local.get 8
    local.get 13
    local.get 21
    i64.add
    local.tee 5
    local.get 10
    local.get 15
    i64.lt_u
    i64.extend_i32_u
    local.get 7
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 9
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 7
    local.get 7
    local.get 12
    local.get 20
    i64.add
    local.tee 8
    local.get 5
    local.get 13
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 10
    i64.add
    local.tee 5
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    i64.const 4294967295
    i64.add
    local.tee 11
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 5
    local.get 5
    local.get 8
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    local.get 6
    i64.add
    local.tee 10
    i64.xor
    local.get 2
    i64.and
    local.get 10
    i64.xor
    i64.store offset=32
    local.get 0
    local.get 1
    i64.load offset=40
    local.get 8
    i64.const 4294967295
    i64.and
    local.tee 12
    local.get 4
    i64.add
    local.tee 5
    local.get 10
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.xor
    local.get 2
    i64.and
    local.get 6
    i64.xor
    i64.store offset=40
    local.get 0
    local.get 1
    i64.load offset=64
    local.get 18
    local.get 26
    i64.add
    local.tee 4
    i64.const 1
    i64.add
    local.tee 13
    i64.eqz
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 10
    local.get 10
    local.get 19
    local.get 27
    i64.add
    local.tee 7
    local.get 4
    local.get 18
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 14
    i64.add
    local.tee 4
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 4
    i64.const -4294967295
    i64.add
    local.tee 15
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 10
    local.get 10
    local.get 17
    local.get 25
    i64.add
    local.tee 4
    local.get 7
    local.get 19
    i64.lt_u
    i64.extend_i32_u
    local.get 14
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 7
    i64.add
    local.tee 14
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 18
    local.get 18
    local.get 16
    local.get 24
    i64.add
    local.tee 10
    local.get 4
    local.get 17
    i64.lt_u
    i64.extend_i32_u
    local.get 7
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 7
    i64.add
    local.tee 4
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 4
    i64.const 4294967295
    i64.add
    local.tee 17
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 4
    local.get 4
    local.get 10
    local.get 16
    i64.lt_u
    i64.extend_i32_u
    local.get 7
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 10
    local.get 13
    i64.add
    local.tee 7
    i64.xor
    local.get 2
    i64.and
    local.get 7
    i64.xor
    i64.store offset=64
    local.get 0
    local.get 1
    i64.load offset=48
    local.get 5
    local.get 12
    i64.lt_u
    i64.extend_i32_u
    local.get 6
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 4
    local.get 9
    i64.add
    local.tee 5
    i64.xor
    local.get 2
    i64.and
    local.get 5
    i64.xor
    i64.store offset=48
    local.get 0
    local.get 1
    i64.load offset=72
    local.get 10
    i64.const 4294967295
    i64.and
    local.tee 9
    local.get 15
    i64.add
    local.tee 6
    local.get 7
    local.get 10
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 7
    i64.xor
    local.get 2
    i64.and
    local.get 7
    i64.xor
    i64.store offset=72
    local.get 0
    local.get 1
    i64.load offset=56
    local.get 8
    i64.const -4294967295
    i64.and
    local.get 11
    i64.add
    local.get 5
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    i64.xor
    local.get 2
    i64.and
    local.get 8
    i64.xor
    i64.store offset=56
    local.get 0
    local.get 1
    i64.load offset=80
    local.get 6
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    local.get 7
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    local.get 14
    i64.add
    local.tee 8
    i64.xor
    local.get 2
    i64.and
    local.get 8
    i64.xor
    i64.store offset=80
    local.get 0
    local.get 1
    i64.load offset=88
    local.get 10
    i64.const -4294967295
    i64.and
    local.get 17
    i64.add
    local.get 8
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 1
    i64.xor
    local.get 2
    i64.and
    local.get 1
    i64.xor
    i64.store offset=88
    local.get 3
    i64.const 352
    i64.add
    global.set $__stack_pointer)
