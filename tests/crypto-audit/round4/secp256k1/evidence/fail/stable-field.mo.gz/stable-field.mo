//MOC-FLAG --package fast /srv/shared/code/motoko_experiments/plugins/_build/signature-round4/secp256k1/packages/fast/src --plugin /srv/shared/code/motoko_experiments/plugins/_build/signature-round4/secp256k1/dist/secp256k1 --sanity-checks
import Curve "mo:fast/Secp256k1";
persistent actor { var key : ?Curve.PreparedSchnorrSecretKey = null };
