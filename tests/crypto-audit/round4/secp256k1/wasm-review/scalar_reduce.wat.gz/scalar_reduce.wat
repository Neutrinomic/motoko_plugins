  (func $_RNvMNtNtNtCsfAt4k4enyRT_4k25610arithmetic6scalar4wideNtB2_10WideScalar11reduce_impl (type 3) (param i64 i64)
    (local i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i32 i64)
    global.get $__stack_pointer
    i64.const 224
    i64.sub
    local.tee 2
    global.set $__stack_pointer
    local.get 2
    i64.const 208
    i64.add
    local.get 1
    i64.load offset=32
    local.tee 3
    i64.const 0
    i64.const 4624529908474429119
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 176
    i64.add
    local.get 1
    i64.load offset=40
    local.tee 4
    i64.const 0
    i64.const 4624529908474429119
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 192
    i64.add
    local.get 3
    i64.const 0
    i64.const 4994812053365940164
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 144
    i64.add
    local.get 1
    i64.load offset=48
    local.tee 5
    i64.const 0
    i64.const 4624529908474429119
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 160
    i64.add
    local.get 4
    i64.const 0
    i64.const 4994812053365940164
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 112
    i64.add
    local.get 1
    i64.load offset=56
    local.tee 6
    i64.const 0
    i64.const 4624529908474429119
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 128
    i64.add
    local.get 5
    i64.const 0
    i64.const 4994812053365940164
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 96
    i64.add
    local.get 6
    i64.const 0
    i64.const 4994812053365940164
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 80
    i64.add
    local.get 5
    local.get 2
    i64.load offset=120
    local.get 2
    i64.load offset=136
    i64.add
    local.get 2
    i64.load offset=152
    local.get 2
    i64.load offset=168
    i64.add
    local.get 2
    i64.load offset=184
    local.get 2
    i64.load offset=200
    i64.add
    local.get 1
    i64.load
    local.tee 7
    local.get 2
    i64.load offset=208
    i64.add
    local.tee 8
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    local.get 2
    i64.load offset=216
    i64.add
    local.tee 9
    local.get 1
    i64.load offset=8
    i64.add
    local.tee 7
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 7
    local.get 2
    i64.load offset=176
    i64.add
    local.tee 9
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 9
    local.get 2
    i64.load offset=192
    i64.add
    local.tee 10
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 9
    local.get 1
    i64.load offset=16
    i64.add
    local.tee 7
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 7
    local.get 2
    i64.load offset=144
    i64.add
    local.tee 9
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 9
    local.get 2
    i64.load offset=160
    i64.add
    local.tee 7
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 7
    local.get 3
    i64.add
    local.tee 9
    local.get 7
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 3
    local.get 1
    i64.load offset=24
    i64.add
    local.tee 1
    local.get 3
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 1
    local.get 2
    i64.load offset=112
    i64.add
    local.tee 3
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 3
    local.get 2
    i64.load offset=128
    i64.add
    local.tee 1
    local.get 3
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 1
    local.get 4
    i64.add
    local.tee 7
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 4
    local.get 2
    i64.load offset=96
    i64.add
    local.tee 3
    i64.add
    local.tee 1
    i64.const 0
    i64.const 4624529908474429119
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 48
    i64.add
    local.get 6
    local.get 3
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    local.get 2
    i64.load offset=104
    i64.add
    local.get 1
    local.get 3
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 11
    i64.add
    local.tee 3
    i64.const 0
    i64.const 4624529908474429119
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 64
    i64.add
    local.get 1
    i64.const 0
    i64.const 4994812053365940164
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 32
    i64.add
    local.get 3
    i64.const 0
    i64.const 4994812053365940164
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 16
    i64.add
    local.get 2
    i64.load offset=56
    local.get 2
    i64.load offset=72
    i64.add
    local.get 8
    local.get 2
    i64.load offset=80
    i64.add
    local.tee 6
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    local.get 2
    i64.load offset=88
    i64.add
    local.tee 5
    local.get 10
    i64.add
    local.tee 4
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 4
    local.get 2
    i64.load offset=48
    i64.add
    local.tee 5
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    local.get 2
    i64.load offset=64
    i64.add
    local.tee 8
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    local.get 9
    i64.add
    local.tee 4
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    local.get 2
    i64.load offset=40
    i64.add
    local.get 4
    i64.const 4624529908474429119
    i64.const 0
    local.get 3
    local.get 11
    i64.lt_u
    local.tee 12
    select
    i64.add
    local.tee 5
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 5
    local.get 2
    i64.load offset=32
    i64.add
    local.tee 4
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 4
    local.get 1
    i64.add
    local.tee 5
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 4
    local.get 7
    i64.add
    local.tee 1
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    local.get 12
    i64.extend_i32_u
    i64.add
    local.get 1
    i64.const 4994812053365940164
    i64.const 0
    local.get 12
    select
    i64.add
    local.tee 4
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 4
    local.get 3
    i64.add
    local.tee 7
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 1
    i64.const 0
    i64.const 4624529908474429119
    i64.const 0
    call $__multi3
    local.get 2
    local.get 1
    i64.const 0
    i64.const 4994812053365940164
    i64.const 0
    call $__multi3
    local.get 0
    local.get 1
    local.get 5
    i64.add
    local.tee 5
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    local.get 5
    local.get 2
    i64.load offset=8
    local.get 2
    i64.load
    local.tee 1
    local.get 8
    i64.add
    local.tee 4
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 4
    local.get 2
    i64.load offset=24
    local.get 2
    i64.load offset=16
    local.tee 3
    local.get 6
    i64.add
    local.tee 1
    local.get 3
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 3
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 4
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    local.get 7
    i64.add
    local.tee 5
    local.get 1
    i64.const 4624529908474429119
    i64.add
    local.tee 7
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.const -1
    i64.add
    local.tee 6
    local.get 3
    local.get 6
    i64.add
    local.tee 6
    local.get 3
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 6
    i64.const 4994812053365940165
    i64.add
    local.tee 9
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    local.get 4
    local.get 6
    i64.add
    local.tee 6
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 6
    i64.const 2
    i64.add
    local.tee 10
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_s
    local.tee 6
    i64.add
    local.tee 11
    i64.const 1
    i64.add
    local.tee 13
    local.get 5
    i64.xor
    i64.const 0
    local.get 5
    local.get 8
    i64.lt_u
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    local.get 6
    local.get 11
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 13
    i64.eqz
    i64.extend_i32_u
    i64.add
    i64.const -1
    i64.add
    i64.const 63
    i64.shr_u
    i32.wrap_i64
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    i32.const -1
    i32.xor
    i32.const 1
    i32.and
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    i32.or
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    i64.extend_i32_u
    i64.const 255
    i64.and
    i64.sub
    local.tee 6
    i64.and
    local.get 5
    i64.xor
    i64.store offset=24
    local.get 0
    local.get 10
    local.get 4
    i64.xor
    local.get 6
    i64.and
    local.get 4
    i64.xor
    i64.store offset=16
    local.get 0
    local.get 9
    local.get 3
    i64.xor
    local.get 6
    i64.and
    local.get 3
    i64.xor
    i64.store offset=8
    local.get 0
    local.get 7
    local.get 1
    i64.xor
    local.get 6
    i64.and
    local.get 1
    i64.xor
    i64.store
    local.get 2
    i64.const 224
    i64.add
    global.set $__stack_pointer)
