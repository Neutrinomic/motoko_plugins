  (func $_RNvNtNtCsfAt4k4enyRT_4k25610arithmetic10fixed_base6select (type 9) (param i64 i64 i32)
    (local i64 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i64 i64 i64 i64 i32 i32 i32)
    global.get $__stack_pointer
    i64.const 176
    i64.sub
    local.tee 3
    global.set $__stack_pointer
    local.get 3
    i64.const 92
    i64.add
    global.get $__memory_base
    i64.const 104
    i64.add
    local.get 1
    local.get 2
    local.get 2
    i32.extend8_s
    i32.const 7
    i32.shr_s
    local.tee 4
    i32.xor
    local.get 4
    i32.sub
    i32.const 255
    i32.and
    local.tee 4
    i32.const 1
    i32.eq
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    call $_RNvXs2_NtNtCsfAt4k4enyRT_4k25610arithmetic6affineNtB5_11AffinePointNtCsa76Hhft0kBi_6subtle23ConditionallySelectable18conditional_select
    local.get 3
    i64.const 8
    i64.add
    local.get 3
    i64.const 92
    i64.add
    i64.const 84
    memory.copy
    local.get 3
    i64.const 92
    i64.add
    local.get 3
    i64.const 8
    i64.add
    local.get 1
    i64.const 84
    i64.add
    local.get 4
    i32.const 2
    i32.eq
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    call $_RNvXs2_NtNtCsfAt4k4enyRT_4k25610arithmetic6affineNtB5_11AffinePointNtCsa76Hhft0kBi_6subtle23ConditionallySelectable18conditional_select
    local.get 3
    i64.const 8
    i64.add
    local.get 3
    i64.const 92
    i64.add
    i64.const 84
    memory.copy
    local.get 3
    i64.const 92
    i64.add
    local.get 3
    i64.const 8
    i64.add
    local.get 1
    i64.const 168
    i64.add
    local.get 4
    i32.const 3
    i32.eq
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    call $_RNvXs2_NtNtCsfAt4k4enyRT_4k25610arithmetic6affineNtB5_11AffinePointNtCsa76Hhft0kBi_6subtle23ConditionallySelectable18conditional_select
    local.get 3
    i64.const 8
    i64.add
    local.get 3
    i64.const 92
    i64.add
    i64.const 84
    memory.copy
    local.get 3
    i64.const 92
    i64.add
    local.get 3
    i64.const 8
    i64.add
    local.get 1
    i64.const 252
    i64.add
    local.get 4
    i32.const 4
    i32.eq
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    call $_RNvXs2_NtNtCsfAt4k4enyRT_4k25610arithmetic6affineNtB5_11AffinePointNtCsa76Hhft0kBi_6subtle23ConditionallySelectable18conditional_select
    local.get 3
    i64.const 8
    i64.add
    local.get 3
    i64.const 92
    i64.add
    i64.const 84
    memory.copy
    local.get 3
    i64.const 92
    i64.add
    local.get 3
    i64.const 8
    i64.add
    local.get 1
    i64.const 336
    i64.add
    local.get 4
    i32.const 5
    i32.eq
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    call $_RNvXs2_NtNtCsfAt4k4enyRT_4k25610arithmetic6affineNtB5_11AffinePointNtCsa76Hhft0kBi_6subtle23ConditionallySelectable18conditional_select
    local.get 3
    i64.const 8
    i64.add
    local.get 3
    i64.const 92
    i64.add
    i64.const 84
    memory.copy
    local.get 3
    i64.const 92
    i64.add
    local.get 3
    i64.const 8
    i64.add
    local.get 1
    i64.const 420
    i64.add
    local.get 4
    i32.const 6
    i32.eq
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    call $_RNvXs2_NtNtCsfAt4k4enyRT_4k25610arithmetic6affineNtB5_11AffinePointNtCsa76Hhft0kBi_6subtle23ConditionallySelectable18conditional_select
    local.get 3
    i64.const 8
    i64.add
    local.get 3
    i64.const 92
    i64.add
    i64.const 84
    memory.copy
    local.get 3
    i64.const 92
    i64.add
    local.get 3
    i64.const 8
    i64.add
    local.get 1
    i64.const 504
    i64.add
    local.get 4
    i32.const 7
    i32.eq
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    call $_RNvXs2_NtNtCsfAt4k4enyRT_4k25610arithmetic6affineNtB5_11AffinePointNtCsa76Hhft0kBi_6subtle23ConditionallySelectable18conditional_select
    local.get 3
    i64.const 8
    i64.add
    local.get 3
    i64.const 92
    i64.add
    i64.const 84
    memory.copy
    local.get 3
    i64.const 92
    i64.add
    local.get 3
    i64.const 8
    i64.add
    local.get 1
    i64.const 588
    i64.add
    local.get 4
    i32.const 8
    i32.eq
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    call $_RNvXs2_NtNtCsfAt4k4enyRT_4k25610arithmetic6affineNtB5_11AffinePointNtCsa76Hhft0kBi_6subtle23ConditionallySelectable18conditional_select
    local.get 3
    i64.const 8
    i64.add
    local.get 3
    i64.const 92
    i64.add
    i64.const 84
    memory.copy
    local.get 3
    i32.load offset=80
    local.set 5
    local.get 3
    i32.load offset=76
    local.set 6
    local.get 3
    i32.load offset=72
    local.set 7
    local.get 3
    i32.load offset=68
    local.set 8
    local.get 3
    i32.load offset=64
    local.set 9
    local.get 3
    i32.load offset=60
    local.set 10
    local.get 3
    i32.load offset=56
    local.set 11
    local.get 3
    i32.load offset=52
    local.set 12
    local.get 3
    i32.load offset=48
    local.set 13
    local.get 3
    i32.load offset=84
    local.set 14
    local.get 3
    i64.load offset=8 align=4
    local.set 1
    local.get 3
    i64.load offset=16 align=4
    local.set 15
    local.get 3
    i64.load offset=24 align=4
    local.set 16
    local.get 3
    i64.load offset=32 align=4
    local.set 17
    local.get 3
    i64.load offset=40 align=4
    local.set 18
    local.get 3
    i32.load8_u offset=88
    local.set 4
    local.get 2
    i32.const 128
    i32.and
    i32.const 7
    i32.shr_u
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    local.set 2
    local.get 3
    local.get 4
    i32.store8 offset=88
    local.get 3
    local.get 18
    i64.store offset=40 align=4
    local.get 3
    local.get 17
    i64.store offset=32 align=4
    local.get 3
    local.get 16
    i64.store offset=24 align=4
    local.get 3
    local.get 15
    i64.store offset=16 align=4
    local.get 3
    local.get 1
    i64.store offset=8 align=4
    local.get 3
    local.get 13
    local.get 13
    i32.const 16777212
    local.get 14
    i32.sub
    local.tee 19
    i32.const 22
    i32.shr_u
    local.tee 20
    i32.const 977
    i32.mul
    local.get 13
    i32.sub
    i32.const 268431548
    i32.add
    local.tee 21
    i32.const 67108863
    i32.and
    i32.xor
    i32.const 0
    local.get 2
    i32.const 255
    i32.and
    i32.sub
    local.tee 4
    i32.and
    i32.xor
    i32.store offset=48
    local.get 3
    local.get 12
    local.get 12
    local.get 20
    i32.const 6
    i32.shl
    local.get 12
    i32.sub
    local.get 21
    i32.const 26
    i32.shr_u
    i32.add
    i32.const 268435196
    i32.add
    local.tee 2
    i32.const 67108863
    i32.and
    i32.xor
    local.get 4
    i32.and
    i32.xor
    i32.store offset=52
    local.get 3
    local.get 11
    local.get 11
    local.get 2
    i32.const 26
    i32.shr_u
    local.get 11
    i32.sub
    i32.const 268435452
    i32.add
    local.tee 2
    i32.const 67108863
    i32.and
    i32.xor
    local.get 4
    i32.and
    i32.xor
    i32.store offset=56
    local.get 3
    local.get 10
    local.get 10
    local.get 2
    i32.const 26
    i32.shr_u
    local.get 10
    i32.sub
    i32.const 268435452
    i32.add
    local.tee 2
    i32.const 67108863
    i32.and
    i32.xor
    local.get 4
    i32.and
    i32.xor
    i32.store offset=60
    local.get 3
    local.get 9
    local.get 9
    local.get 2
    i32.const 26
    i32.shr_u
    local.get 9
    i32.sub
    i32.const 268435452
    i32.add
    local.tee 2
    i32.const 67108863
    i32.and
    i32.xor
    local.get 4
    i32.and
    i32.xor
    i32.store offset=64
    local.get 3
    local.get 8
    local.get 8
    local.get 2
    i32.const 26
    i32.shr_u
    local.get 8
    i32.sub
    i32.const 268435452
    i32.add
    local.tee 2
    i32.const 67108863
    i32.and
    i32.xor
    local.get 4
    i32.and
    i32.xor
    i32.store offset=68
    local.get 3
    local.get 7
    local.get 7
    local.get 2
    i32.const 26
    i32.shr_u
    local.get 7
    i32.sub
    i32.const 268435452
    i32.add
    local.tee 2
    i32.const 67108863
    i32.and
    i32.xor
    local.get 4
    i32.and
    i32.xor
    i32.store offset=72
    local.get 3
    local.get 6
    local.get 6
    local.get 2
    i32.const 26
    i32.shr_u
    local.get 6
    i32.sub
    i32.const 268435452
    i32.add
    local.tee 2
    i32.const 67108863
    i32.and
    i32.xor
    local.get 4
    i32.and
    i32.xor
    i32.store offset=76
    local.get 3
    local.get 5
    local.get 5
    local.get 2
    i32.const 26
    i32.shr_u
    local.get 5
    i32.sub
    i32.const 268435452
    i32.add
    local.tee 2
    i32.const 67108863
    i32.and
    i32.xor
    local.get 4
    i32.and
    i32.xor
    i32.store offset=80
    local.get 3
    local.get 14
    local.get 14
    local.get 2
    i32.const 26
    i32.shr_u
    local.get 19
    i32.const 4194303
    i32.and
    i32.add
    i32.xor
    local.get 4
    i32.and
    i32.xor
    i32.store offset=84
    local.get 0
    local.get 3
    i64.const 8
    i64.add
    i64.const 84
    memory.copy
    local.get 3
    i64.const 176
    i64.add
    global.set $__stack_pointer)
