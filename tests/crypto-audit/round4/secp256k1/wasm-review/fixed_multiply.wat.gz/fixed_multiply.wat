  (func $_RNvXs3_NtNtCsfAt4k4enyRT_4k25610arithmetic3mulNtNtB7_10projective15ProjectivePointNtNtCslIuh6ameXbS_14elliptic_curve3ops14MulByGenerator16mul_by_generator (type 3) (param i64 i64)
    (local i64 i64 i64 i32 i32)
    global.get $__stack_pointer
    i64.const 512
    i64.sub
    local.tee 2
    global.set $__stack_pointer
    local.get 2
    i64.const 327
    i64.add
    i32.const 0
    i64.const 65
    memory.fill
    local.get 2
    local.get 1
    i64.load
    local.tee 3
    i64.const 56
    i64.shl
    local.get 3
    i64.const 65280
    i64.and
    i64.const 40
    i64.shl
    i64.or
    local.get 3
    i64.const 16711680
    i64.and
    i64.const 24
    i64.shl
    local.get 3
    i64.const 4278190080
    i64.and
    i64.const 8
    i64.shl
    i64.or
    i64.or
    local.get 3
    i64.const 8
    i64.shr_u
    i64.const 4278190080
    i64.and
    local.get 3
    i64.const 24
    i64.shr_u
    i64.const 16711680
    i64.and
    i64.or
    local.get 3
    i64.const 40
    i64.shr_u
    i64.const 65280
    i64.and
    local.get 3
    i64.const 56
    i64.shr_u
    i64.or
    i64.or
    i64.or
    i64.store offset=416
    local.get 2
    local.get 1
    i64.load offset=8
    local.tee 3
    i64.const 56
    i64.shl
    local.get 3
    i64.const 65280
    i64.and
    i64.const 40
    i64.shl
    i64.or
    local.get 3
    i64.const 16711680
    i64.and
    i64.const 24
    i64.shl
    local.get 3
    i64.const 4278190080
    i64.and
    i64.const 8
    i64.shl
    i64.or
    i64.or
    local.get 3
    i64.const 8
    i64.shr_u
    i64.const 4278190080
    i64.and
    local.get 3
    i64.const 24
    i64.shr_u
    i64.const 16711680
    i64.and
    i64.or
    local.get 3
    i64.const 40
    i64.shr_u
    i64.const 65280
    i64.and
    local.get 3
    i64.const 56
    i64.shr_u
    i64.or
    i64.or
    i64.or
    i64.store offset=408
    local.get 2
    local.get 1
    i64.load offset=16
    local.tee 3
    i64.const 56
    i64.shl
    local.get 3
    i64.const 65280
    i64.and
    i64.const 40
    i64.shl
    i64.or
    local.get 3
    i64.const 16711680
    i64.and
    i64.const 24
    i64.shl
    local.get 3
    i64.const 4278190080
    i64.and
    i64.const 8
    i64.shl
    i64.or
    i64.or
    local.get 3
    i64.const 8
    i64.shr_u
    i64.const 4278190080
    i64.and
    local.get 3
    i64.const 24
    i64.shr_u
    i64.const 16711680
    i64.and
    i64.or
    local.get 3
    i64.const 40
    i64.shr_u
    i64.const 65280
    i64.and
    local.get 3
    i64.const 56
    i64.shr_u
    i64.or
    i64.or
    i64.or
    i64.store offset=400
    local.get 2
    local.get 1
    i64.load offset=24
    local.tee 3
    i64.const 56
    i64.shl
    local.get 3
    i64.const 65280
    i64.and
    i64.const 40
    i64.shl
    i64.or
    local.get 3
    i64.const 16711680
    i64.and
    i64.const 24
    i64.shl
    local.get 3
    i64.const 4278190080
    i64.and
    i64.const 8
    i64.shl
    i64.or
    i64.or
    local.get 3
    i64.const 8
    i64.shr_u
    i64.const 4278190080
    i64.and
    local.get 3
    i64.const 24
    i64.shr_u
    i64.const 16711680
    i64.and
    i64.or
    local.get 3
    i64.const 40
    i64.shr_u
    i64.const 65280
    i64.and
    local.get 3
    i64.const 56
    i64.shr_u
    i64.or
    i64.or
    i64.or
    i64.store offset=392
    local.get 2
    i64.const 422
    i64.add
    local.set 3
    i64.const 0
    local.set 4
    loop  ;; label = @1
      local.get 2
      i64.const 327
      i64.add
      local.get 4
      i64.add
      local.tee 1
      i64.const 3
      i64.add
      local.get 3
      i32.load8_u
      local.tee 5
      i32.const 4
      i32.shr_u
      i32.store8
      local.get 1
      i64.const 2
      i64.add
      local.get 5
      i32.const 15
      i32.and
      i32.store8
      local.get 1
      i64.const 1
      i64.add
      local.get 3
      i64.const 1
      i64.add
      i32.load8_u
      local.tee 5
      i32.const 4
      i32.shr_u
      i32.store8
      local.get 1
      local.get 5
      i32.const 15
      i32.and
      i32.store8
      local.get 3
      i64.const -2
      i64.add
      local.set 3
      local.get 4
      i64.const 4
      i64.add
      local.tee 4
      i64.const 64
      i64.ne
      br_if 0 (;@1;)
    end
    i64.const 0
    local.set 3
    local.get 2
    i32.load8_u offset=327
    local.set 5
    loop  ;; label = @1
      local.get 2
      i64.const 327
      i64.add
      local.get 3
      i64.add
      local.tee 1
      local.get 5
      local.get 5
      i32.const 8
      i32.add
      local.tee 6
      i32.const 240
      i32.and
      i32.sub
      i32.store8
      local.get 1
      i64.const 1
      i64.add
      local.tee 4
      local.get 4
      i32.load8_u
      local.get 6
      i32.extend8_s
      i32.const 4
      i32.shr_s
      i32.add
      local.tee 5
      local.get 5
      i32.const 8
      i32.add
      local.tee 5
      i32.const 240
      i32.and
      i32.sub
      i32.store8
      local.get 1
      i64.const 2
      i64.add
      local.tee 1
      local.get 1
      i32.load8_u
      local.get 5
      i32.extend8_s
      i32.const 4
      i32.shr_s
      i32.add
      local.tee 5
      i32.store8
      local.get 3
      i64.const 2
      i64.add
      local.tee 3
      i64.const 64
      i64.ne
      br_if 0 (;@1;)
    end
    local.get 2
    i64.const 120
    i64.add
    global.get $__memory_base
    local.tee 1
    i64.const 1808
    i64.add
    i64.const 21504
    i64.add
    local.get 2
    i32.load8_u offset=391
    call $_RNvNtNtCsfAt4k4enyRT_4k25610arithmetic10fixed_base6select
    local.get 2
    local.get 2
    i64.load offset=192 align=4
    i64.store offset=464
    local.get 2
    local.get 2
    i64.load offset=184 align=4
    i64.store offset=456
    local.get 2
    local.get 2
    i64.load offset=176 align=4
    i64.store offset=448
    local.get 2
    local.get 2
    i64.load offset=168 align=4
    i64.store offset=440
    local.get 2
    local.get 2
    i64.load offset=160 align=4
    i64.store offset=432
    local.get 2
    local.get 2
    i64.load offset=120 align=4
    i64.store offset=392
    local.get 2
    local.get 2
    i64.load offset=128 align=4
    i64.store offset=400
    local.get 2
    local.get 2
    i64.load offset=136 align=4
    i64.store offset=408
    local.get 2
    local.get 2
    i64.load offset=144 align=4
    i64.store offset=416
    local.get 2
    local.get 2
    i64.load offset=152 align=4
    i64.store offset=424
    local.get 2
    local.get 1
    i64.const 228
    i64.add
    local.tee 3
    i64.load offset=32 align=4
    i64.store offset=504
    local.get 2
    local.get 3
    i64.load offset=24 align=4
    i64.store offset=496
    local.get 2
    local.get 3
    i64.load offset=16 align=4
    i64.store offset=488
    local.get 2
    local.get 3
    i64.load offset=8 align=4
    i64.store offset=480
    local.get 2
    local.get 3
    i64.load align=4
    i64.store offset=472
    local.get 2
    local.get 2
    i64.const 392
    i64.add
    local.get 1
    i64.const 268
    i64.add
    local.tee 3
    local.get 2
    i32.load8_u offset=200
    call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
    call $_RNvXs6_NtNtCsfAt4k4enyRT_4k25610arithmetic10projectiveNtB5_15ProjectivePointNtCsa76Hhft0kBi_6subtle23ConditionallySelectable18conditional_select
    local.get 2
    i64.const 120
    i64.add
    local.get 3
    i64.const 120
    memory.copy
    local.get 2
    i64.const 389
    i64.add
    local.set 3
    i64.const 20832
    local.set 1
    loop  ;; label = @1
      local.get 2
      i64.const 240
      i64.add
      global.get $__memory_base
      i64.const 1808
      i64.add
      local.get 1
      i64.add
      local.tee 4
      local.get 3
      i64.const 1
      i64.add
      i32.load8_u
      call $_RNvNtNtCsfAt4k4enyRT_4k25610arithmetic10fixed_base6select
      local.get 2
      i64.const 392
      i64.add
      local.get 2
      i64.const 120
      i64.add
      local.get 2
      i64.const 240
      i64.add
      call $_RNvMNtNtCsfAt4k4enyRT_4k25610arithmetic10projectiveNtB2_15ProjectivePoint9add_mixed
      local.get 2
      i64.const 120
      i64.add
      local.get 2
      i64.const 392
      i64.add
      i64.const 120
      memory.copy
      local.get 2
      i64.const 240
      i64.add
      local.get 4
      local.get 3
      i32.load8_u
      call $_RNvNtNtCsfAt4k4enyRT_4k25610arithmetic10fixed_base6select
      local.get 2
      i64.const 392
      i64.add
      local.get 2
      local.get 2
      i64.const 240
      i64.add
      call $_RNvMNtNtCsfAt4k4enyRT_4k25610arithmetic10projectiveNtB2_15ProjectivePoint9add_mixed
      local.get 2
      local.get 2
      i64.const 392
      i64.add
      i64.const 120
      memory.copy
      local.get 3
      i64.const -2
      i64.add
      local.set 3
      local.get 1
      i64.const -672
      i64.add
      local.tee 1
      i64.const -672
      i64.ne
      br_if 0 (;@1;)
    end
    local.get 2
    i64.const 392
    i64.add
    local.get 2
    i64.const 120
    i64.add
    call $_RNvMNtNtCsfAt4k4enyRT_4k25610arithmetic10projectiveNtB2_15ProjectivePoint6double
    local.get 2
    i64.const 120
    i64.add
    local.get 2
    i64.const 392
    i64.add
    i64.const 120
    memory.copy
    local.get 2
    i64.const 392
    i64.add
    local.get 2
    i64.const 120
    i64.add
    call $_RNvMNtNtCsfAt4k4enyRT_4k25610arithmetic10projectiveNtB2_15ProjectivePoint6double
    local.get 2
    i64.const 120
    i64.add
    local.get 2
    i64.const 392
    i64.add
    i64.const 120
    memory.copy
    local.get 2
    i64.const 392
    i64.add
    local.get 2
    i64.const 120
    i64.add
    call $_RNvMNtNtCsfAt4k4enyRT_4k25610arithmetic10projectiveNtB2_15ProjectivePoint6double
    local.get 2
    i64.const 120
    i64.add
    local.get 2
    i64.const 392
    i64.add
    i64.const 120
    memory.copy
    local.get 2
    i64.const 392
    i64.add
    local.get 2
    i64.const 120
    i64.add
    call $_RNvMNtNtCsfAt4k4enyRT_4k25610arithmetic10projectiveNtB2_15ProjectivePoint6double
    local.get 2
    i64.const 120
    i64.add
    local.get 2
    i64.const 392
    i64.add
    i64.const 120
    memory.copy
    local.get 0
    local.get 2
    local.get 2
    i64.const 120
    i64.add
    call $_RNvMNtNtCsfAt4k4enyRT_4k25610arithmetic10projectiveNtB2_15ProjectivePoint3add
    local.get 2
    i64.const 512
    i64.add
    global.set $__stack_pointer)
