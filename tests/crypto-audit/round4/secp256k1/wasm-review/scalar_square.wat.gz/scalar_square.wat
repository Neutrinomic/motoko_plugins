  (func $_RNvMNtNtCsfAt4k4enyRT_4k25610arithmetic6scalarNtB2_6Scalar6square (type 3) (param i64 i64)
    (local i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64 i64)
    global.get $__stack_pointer
    i64.const 224
    i64.sub
    local.tee 2
    global.set $__stack_pointer
    local.get 2
    local.get 1
    i64.load
    local.tee 3
    i64.const 0
    local.get 1
    i64.load offset=8
    local.tee 4
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 16
    i64.add
    local.get 1
    i64.load offset=16
    local.tee 5
    i64.const 0
    local.get 3
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 64
    i64.add
    local.get 5
    i64.const 0
    local.get 4
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 32
    i64.add
    local.get 1
    i64.load offset=24
    local.tee 1
    i64.const 0
    local.get 3
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 80
    i64.add
    local.get 1
    i64.const 0
    local.get 4
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 112
    i64.add
    local.get 1
    i64.const 0
    local.get 5
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 48
    i64.add
    local.get 3
    i64.const 0
    local.get 3
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 96
    i64.add
    local.get 4
    i64.const 0
    local.get 4
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 128
    i64.add
    local.get 5
    i64.const 0
    local.get 5
    i64.const 0
    call $__multi3
    local.get 2
    i64.const 144
    i64.add
    local.get 1
    i64.const 0
    local.get 1
    i64.const 0
    call $__multi3
    local.get 2
    local.get 2
    i64.load offset=48
    i64.store offset=160
    local.get 2
    i64.load offset=16
    local.set 6
    local.get 2
    i64.load offset=8
    local.set 1
    local.get 2
    i64.load offset=24
    local.set 7
    local.get 2
    i64.load offset=64
    local.set 8
    local.get 2
    i64.load offset=72
    local.set 9
    local.get 2
    i64.load offset=80
    local.set 10
    local.get 2
    i64.load offset=88
    local.set 11
    local.get 2
    i64.load offset=32
    local.set 12
    local.get 2
    i64.load offset=40
    local.set 13
    local.get 2
    i64.load offset=112
    local.set 14
    local.get 2
    i64.load offset=120
    local.set 15
    local.get 2
    i64.load offset=144
    local.set 3
    local.get 2
    i64.load offset=128
    local.set 4
    local.get 2
    local.get 2
    i64.load
    local.tee 16
    i64.const 1
    i64.shl
    local.tee 5
    local.get 2
    i64.load offset=56
    i64.add
    local.tee 17
    i64.store offset=168
    local.get 2
    local.get 2
    i64.load offset=96
    local.tee 18
    local.get 17
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 5
    local.get 1
    local.get 6
    i64.add
    local.tee 6
    i64.const 1
    i64.shl
    local.get 16
    i64.const 63
    i64.shr_u
    i64.or
    i64.add
    local.tee 16
    i64.store offset=176
    local.get 2
    local.get 12
    local.get 8
    local.get 7
    local.get 6
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 17
    i64.add
    local.tee 1
    i64.add
    local.tee 7
    i64.const 1
    i64.shl
    local.get 6
    i64.const 63
    i64.shr_u
    i64.or
    local.tee 8
    local.get 2
    i64.load offset=104
    local.get 5
    local.get 18
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 16
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 12
    i64.store offset=184
    local.get 2
    local.get 4
    local.get 10
    local.get 9
    local.get 1
    local.get 17
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 9
    i64.add
    local.tee 5
    local.get 13
    local.get 7
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 1
    i64.const 1
    i64.shl
    local.get 7
    i64.const 63
    i64.shr_u
    i64.or
    i64.add
    local.tee 6
    local.get 12
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 7
    i64.store offset=192
    local.get 2
    local.get 14
    local.get 11
    local.get 5
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 1
    local.get 5
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 8
    i64.add
    local.tee 5
    i64.const 1
    i64.shl
    local.get 1
    i64.const 63
    i64.shr_u
    i64.or
    local.tee 9
    local.get 2
    i64.load offset=136
    local.get 6
    local.get 4
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 7
    local.get 6
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    local.tee 4
    i64.store offset=200
    local.get 2
    local.get 3
    local.get 15
    local.get 5
    local.get 8
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 6
    i64.const 1
    i64.shl
    local.get 5
    i64.const 63
    i64.shr_u
    i64.or
    i64.add
    local.tee 1
    local.get 4
    local.get 9
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.tee 4
    i64.store offset=208
    local.get 2
    local.get 6
    i64.const 63
    i64.shr_u
    local.get 2
    i64.load offset=152
    local.get 1
    local.get 3
    i64.lt_u
    i64.extend_i32_u
    i64.add
    local.get 4
    local.get 1
    i64.lt_u
    i64.extend_i32_u
    i64.add
    i64.add
    i64.store offset=216
    local.get 0
    local.get 2
    i64.const 160
    i64.add
    call $_RNvMNtNtNtCsfAt4k4enyRT_4k25610arithmetic6scalar4wideNtB2_10WideScalar11reduce_impl
    local.get 2
    i64.const 224
    i64.add
    global.set $__stack_pointer)
