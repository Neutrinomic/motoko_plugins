  (func $_RNvMNtNtCsfAt4k4enyRT_4k25610arithmetic10projectiveNtB2_15ProjectivePoint24x_matches_scalar_vartime (type 7) (param i64 i64) (result i32)
    (local i64 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i64 i32 i32 i32 i32 i32 i32 i32 i32 i32)
    global.get $__stack_pointer
    i64.const 160
    i64.sub
    local.tee 2
    global.set $__stack_pointer
    i32.const 0
    local.set 3
    block  ;; label = @1
      local.get 0
      i32.load offset=84
      local.get 0
      i32.load offset=116
      local.tee 4
      i32.const 22
      i32.shr_u
      local.tee 5
      i32.const 6
      i32.shl
      i32.add
      local.get 5
      i32.const 977
      i32.mul
      local.get 0
      i32.load offset=80
      i32.add
      local.tee 5
      i32.const 26
      i32.shr_u
      i32.add
      local.tee 6
      local.get 5
      i32.or
      local.get 6
      i32.const 26
      i32.shr_u
      local.get 0
      i32.load offset=88
      i32.add
      local.tee 7
      i32.or
      local.get 7
      i32.const 26
      i32.shr_u
      local.get 0
      i32.load offset=92
      i32.add
      local.tee 8
      i32.or
      local.get 8
      i32.const 26
      i32.shr_u
      local.get 0
      i32.load offset=96
      i32.add
      local.tee 9
      i32.or
      local.get 9
      i32.const 26
      i32.shr_u
      local.get 0
      i32.load offset=100
      i32.add
      local.tee 10
      i32.or
      local.get 10
      i32.const 26
      i32.shr_u
      local.get 0
      i32.load offset=104
      i32.add
      local.tee 11
      i32.or
      local.get 11
      i32.const 26
      i32.shr_u
      local.get 0
      i32.load offset=108
      i32.add
      local.tee 12
      i32.or
      local.get 12
      i32.const 26
      i32.shr_u
      local.get 0
      i32.load offset=112
      i32.add
      local.tee 13
      i32.or
      i32.const 67108863
      i32.and
      local.get 13
      i32.const 26
      i32.shr_u
      local.get 4
      i32.const 4194303
      i32.and
      i32.add
      local.tee 4
      i32.or
      i32.eqz
      local.get 6
      i32.const 64
      i32.xor
      local.get 5
      i32.const 976
      i32.xor
      i32.and
      local.get 4
      i32.const 62914560
      i32.xor
      i32.and
      local.get 7
      i32.and
      local.get 8
      i32.and
      local.get 9
      i32.and
      local.get 10
      i32.and
      local.get 11
      i32.and
      local.get 12
      i32.and
      local.get 13
      i32.and
      i32.const 67108863
      i32.eq
      i32.or
      call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
      i32.const 255
      i32.and
      br_if 0 (;@1;)
      local.get 2
      local.get 1
      i64.load
      local.tee 14
      i64.const 56
      i64.shl
      local.get 14
      i64.const 65280
      i64.and
      i64.const 40
      i64.shl
      i64.or
      local.get 14
      i64.const 16711680
      i64.and
      i64.const 24
      i64.shl
      local.get 14
      i64.const 4278190080
      i64.and
      i64.const 8
      i64.shl
      i64.or
      i64.or
      local.get 14
      i64.const 8
      i64.shr_u
      i64.const 4278190080
      i64.and
      local.get 14
      i64.const 24
      i64.shr_u
      i64.const 16711680
      i64.and
      i64.or
      local.get 14
      i64.const 40
      i64.shr_u
      i64.const 65280
      i64.and
      local.get 14
      i64.const 56
      i64.shr_u
      i64.or
      i64.or
      i64.or
      i64.store offset=32
      local.get 2
      local.get 1
      i64.load offset=8
      local.tee 14
      i64.const 56
      i64.shl
      local.get 14
      i64.const 65280
      i64.and
      i64.const 40
      i64.shl
      i64.or
      local.get 14
      i64.const 16711680
      i64.and
      i64.const 24
      i64.shl
      local.get 14
      i64.const 4278190080
      i64.and
      i64.const 8
      i64.shl
      i64.or
      i64.or
      local.get 14
      i64.const 8
      i64.shr_u
      i64.const 4278190080
      i64.and
      local.get 14
      i64.const 24
      i64.shr_u
      i64.const 16711680
      i64.and
      i64.or
      local.get 14
      i64.const 40
      i64.shr_u
      i64.const 65280
      i64.and
      local.get 14
      i64.const 56
      i64.shr_u
      i64.or
      i64.or
      i64.or
      i64.store offset=24
      local.get 2
      local.get 1
      i64.load offset=16
      local.tee 14
      i64.const 56
      i64.shl
      local.get 14
      i64.const 65280
      i64.and
      i64.const 40
      i64.shl
      i64.or
      local.get 14
      i64.const 16711680
      i64.and
      i64.const 24
      i64.shl
      local.get 14
      i64.const 4278190080
      i64.and
      i64.const 8
      i64.shl
      i64.or
      i64.or
      local.get 14
      i64.const 8
      i64.shr_u
      i64.const 4278190080
      i64.and
      local.get 14
      i64.const 24
      i64.shr_u
      i64.const 16711680
      i64.and
      i64.or
      local.get 14
      i64.const 40
      i64.shr_u
      i64.const 65280
      i64.and
      local.get 14
      i64.const 56
      i64.shr_u
      i64.or
      i64.or
      i64.or
      i64.store offset=16
      local.get 2
      local.get 1
      i64.load offset=24
      local.tee 14
      i64.const 56
      i64.shl
      local.get 14
      i64.const 65280
      i64.and
      i64.const 40
      i64.shl
      i64.or
      local.get 14
      i64.const 16711680
      i64.and
      i64.const 24
      i64.shl
      local.get 14
      i64.const 4278190080
      i64.and
      i64.const 8
      i64.shl
      i64.or
      i64.or
      local.get 14
      i64.const 8
      i64.shr_u
      i64.const 4278190080
      i64.and
      local.get 14
      i64.const 24
      i64.shr_u
      i64.const 16711680
      i64.and
      i64.or
      local.get 14
      i64.const 40
      i64.shr_u
      i64.const 65280
      i64.and
      local.get 14
      i64.const 56
      i64.shr_u
      i64.or
      i64.or
      i64.or
      i64.store offset=8
      local.get 2
      i64.const 40
      i64.add
      local.get 2
      i64.const 8
      i64.add
      call $_RNvMNtNtNtCsfAt4k4enyRT_4k25610arithmetic5field11field_10x26NtB2_17FieldElement10x2620from_bytes_unchecked
      local.get 2
      i64.const 120
      i64.add
      local.get 2
      i64.const 40
      i64.add
      local.get 0
      i64.const 80
      i64.add
      local.tee 14
      call $_RNvMNtNtNtCsfAt4k4enyRT_4k25610arithmetic5field11field_10x26NtB2_17FieldElement10x263mul
      block  ;; label = @2
        local.get 0
        i32.load offset=4
        local.tee 4
        local.get 2
        i32.load offset=124
        i32.sub
        local.get 0
        i32.load offset=36
        local.tee 15
        local.get 2
        i32.load offset=156
        i32.sub
        i32.const 16777212
        i32.add
        local.tee 3
        i32.const 22
        i32.shr_u
        local.tee 5
        i32.const 6
        i32.shl
        i32.add
        local.get 0
        i32.load
        local.tee 16
        local.get 2
        i32.load offset=120
        i32.sub
        local.get 5
        i32.const 977
        i32.mul
        i32.add
        i32.const 268431548
        i32.add
        local.tee 5
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435196
        i32.add
        local.tee 6
        local.get 5
        i32.or
        local.get 0
        i32.load offset=8
        local.tee 17
        local.get 2
        i32.load offset=128
        i32.sub
        local.get 6
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 7
        i32.or
        local.get 0
        i32.load offset=12
        local.tee 18
        local.get 2
        i32.load offset=132
        i32.sub
        local.get 7
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 8
        i32.or
        local.get 0
        i32.load offset=16
        local.tee 19
        local.get 2
        i32.load offset=136
        i32.sub
        local.get 8
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 9
        i32.or
        local.get 0
        i32.load offset=20
        local.tee 20
        local.get 2
        i32.load offset=140
        i32.sub
        local.get 9
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 10
        i32.or
        local.get 0
        i32.load offset=24
        local.tee 21
        local.get 2
        i32.load offset=144
        i32.sub
        local.get 10
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 11
        i32.or
        local.get 0
        i32.load offset=28
        local.tee 22
        local.get 2
        i32.load offset=148
        i32.sub
        local.get 11
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 12
        i32.or
        local.get 0
        i32.load offset=32
        local.tee 23
        local.get 2
        i32.load offset=152
        i32.sub
        local.get 12
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 13
        i32.or
        i32.const 67108863
        i32.and
        local.get 13
        i32.const 26
        i32.shr_u
        local.get 3
        i32.const 4194303
        i32.and
        i32.add
        local.tee 3
        i32.or
        i32.eqz
        local.get 6
        i32.const 64
        i32.xor
        local.get 5
        i32.const 976
        i32.xor
        i32.and
        local.get 3
        i32.const 62914560
        i32.xor
        i32.and
        local.get 7
        i32.and
        local.get 8
        i32.and
        local.get 9
        i32.and
        local.get 10
        i32.and
        local.get 11
        i32.and
        local.get 12
        i32.and
        local.get 13
        i32.and
        i32.const 67108863
        i32.eq
        i32.or
        call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
        i32.const 255
        i32.and
        local.tee 5
        br_if 0 (;@2;)
        i64.const 0
        local.set 1
        block  ;; label = @3
          block  ;; label = @4
            local.get 2
            i64.load offset=8
            local.tee 0
            i64.const 56
            i64.shl
            local.get 0
            i64.const 65280
            i64.and
            i64.const 40
            i64.shl
            i64.or
            local.get 0
            i64.const 16711680
            i64.and
            i64.const 24
            i64.shl
            local.get 0
            i64.const 4278190080
            i64.and
            i64.const 8
            i64.shl
            i64.or
            i64.or
            local.get 0
            i64.const 8
            i64.shr_u
            i64.const 4278190080
            i64.and
            local.get 0
            i64.const 24
            i64.shr_u
            i64.const 16711680
            i64.and
            i64.or
            local.get 0
            i64.const 40
            i64.shr_u
            i64.const 65280
            i64.and
            local.get 0
            i64.const 56
            i64.shr_u
            i64.or
            i64.or
            i64.or
            local.tee 0
            i64.eqz
            i32.eqz
            br_if 0 (;@4;)
            i64.const 1
            local.set 1
            local.get 2
            i64.const 8
            i64.add
            i64.const 8
            i64.add
            i64.load
            local.tee 0
            i64.const 56
            i64.shl
            local.get 0
            i64.const 65280
            i64.and
            i64.const 40
            i64.shl
            i64.or
            local.get 0
            i64.const 16711680
            i64.and
            i64.const 24
            i64.shl
            local.get 0
            i64.const 4278190080
            i64.and
            i64.const 8
            i64.shl
            i64.or
            i64.or
            local.get 0
            i64.const 8
            i64.shr_u
            i64.const 4278190080
            i64.and
            local.get 0
            i64.const 24
            i64.shr_u
            i64.const 16711680
            i64.and
            i64.or
            local.get 0
            i64.const 40
            i64.shr_u
            i64.const 65280
            i64.and
            local.get 0
            i64.const 56
            i64.shr_u
            i64.or
            i64.or
            i64.or
            local.tee 0
            i64.const 1
            i64.ne
            br_if 0 (;@4;)
            i64.const 4994812053365940164
            local.set 1
            local.get 2
            i64.const 24
            i64.add
            i64.load
            local.tee 0
            i64.const 56
            i64.shl
            local.get 0
            i64.const 65280
            i64.and
            i64.const 40
            i64.shl
            i64.or
            local.get 0
            i64.const 16711680
            i64.and
            i64.const 24
            i64.shl
            local.get 0
            i64.const 4278190080
            i64.and
            i64.const 8
            i64.shl
            i64.or
            i64.or
            local.get 0
            i64.const 8
            i64.shr_u
            i64.const 4278190080
            i64.and
            local.get 0
            i64.const 24
            i64.shr_u
            i64.const 16711680
            i64.and
            i64.or
            local.get 0
            i64.const 40
            i64.shr_u
            i64.const 65280
            i64.and
            local.get 0
            i64.const 56
            i64.shr_u
            i64.or
            i64.or
            i64.or
            local.tee 0
            i64.const 4994812053365940164
            i64.ne
            br_if 0 (;@4;)
            i64.const 4624529904179460846
            local.set 1
            i32.const 0
            local.set 6
            local.get 2
            i64.const 8
            i64.add
            i64.const 24
            i64.add
            i64.load
            local.tee 0
            i64.const 56
            i64.shl
            local.get 0
            i64.const 65280
            i64.and
            i64.const 40
            i64.shl
            i64.or
            local.get 0
            i64.const 16711680
            i64.and
            i64.const 24
            i64.shl
            local.get 0
            i64.const 4278190080
            i64.and
            i64.const 8
            i64.shl
            i64.or
            i64.or
            local.get 0
            i64.const 8
            i64.shr_u
            i64.const 4278190080
            i64.and
            local.get 0
            i64.const 24
            i64.shr_u
            i64.const 16711680
            i64.and
            i64.or
            local.get 0
            i64.const 40
            i64.shr_u
            i64.const 65280
            i64.and
            local.get 0
            i64.const 56
            i64.shr_u
            i64.or
            i64.or
            i64.or
            local.tee 0
            i64.const 4624529904179460846
            i64.eq
            br_if 1 (;@3;)
          end
          i32.const -1
          i32.const 1
          local.get 0
          local.get 1
          i64.lt_u
          select
          local.set 6
        end
        local.get 6
        i32.const -1
        i32.gt_s
        br_if 0 (;@2;)
        local.get 2
        local.get 2
        i32.load offset=76
        i32.const 4194303
        i32.add
        i32.store offset=156
        local.get 2
        local.get 2
        i32.load offset=72
        i32.const 67108863
        i32.add
        i32.store offset=152
        local.get 2
        local.get 2
        i32.load offset=68
        i32.const 67108863
        i32.add
        i32.store offset=148
        local.get 2
        local.get 2
        i32.load offset=64
        i32.const 67108863
        i32.add
        i32.store offset=144
        local.get 2
        local.get 2
        i32.load offset=60
        i32.const 67108863
        i32.add
        i32.store offset=140
        local.get 2
        local.get 2
        i32.load offset=56
        i32.const 45788892
        i32.add
        i32.store offset=136
        local.get 2
        local.get 2
        i32.load offset=52
        i32.const 60472610
        i32.add
        i32.store offset=132
        local.get 2
        local.get 2
        i32.load offset=48
        i32.const 33799165
        i32.add
        i32.store offset=128
        local.get 2
        local.get 2
        i32.load offset=44
        i32.const 9937716
        i32.add
        i32.store offset=124
        local.get 2
        local.get 2
        i32.load offset=40
        i32.const 3555649
        i32.add
        i32.store offset=120
        local.get 2
        i64.const 80
        i64.add
        local.get 2
        i64.const 120
        i64.add
        local.get 14
        call $_RNvMNtNtNtCsfAt4k4enyRT_4k25610arithmetic5field11field_10x26NtB2_17FieldElement10x263mul
        local.get 4
        local.get 2
        i32.load offset=84
        i32.sub
        local.get 15
        local.get 2
        i32.load offset=116
        i32.sub
        i32.const 16777212
        i32.add
        local.tee 3
        i32.const 22
        i32.shr_u
        local.tee 5
        i32.const 6
        i32.shl
        i32.add
        local.get 16
        local.get 2
        i32.load offset=80
        i32.sub
        local.get 5
        i32.const 977
        i32.mul
        i32.add
        i32.const 268431548
        i32.add
        local.tee 5
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435196
        i32.add
        local.tee 6
        local.get 5
        i32.or
        local.get 17
        local.get 2
        i32.load offset=88
        i32.sub
        local.get 6
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 7
        i32.or
        local.get 18
        local.get 2
        i32.load offset=92
        i32.sub
        local.get 7
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 8
        i32.or
        local.get 19
        local.get 2
        i32.load offset=96
        i32.sub
        local.get 8
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 9
        i32.or
        local.get 20
        local.get 2
        i32.load offset=100
        i32.sub
        local.get 9
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 10
        i32.or
        local.get 21
        local.get 2
        i32.load offset=104
        i32.sub
        local.get 10
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 11
        i32.or
        local.get 22
        local.get 2
        i32.load offset=108
        i32.sub
        local.get 11
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 12
        i32.or
        local.get 23
        local.get 2
        i32.load offset=112
        i32.sub
        local.get 12
        i32.const 26
        i32.shr_u
        i32.add
        i32.const 268435452
        i32.add
        local.tee 13
        i32.or
        i32.const 67108863
        i32.and
        local.get 13
        i32.const 26
        i32.shr_u
        local.get 3
        i32.const 4194303
        i32.and
        i32.add
        local.tee 3
        i32.or
        i32.eqz
        local.get 6
        i32.const 64
        i32.xor
        local.get 5
        i32.const 976
        i32.xor
        i32.and
        local.get 3
        i32.const 62914560
        i32.xor
        i32.and
        local.get 7
        i32.and
        local.get 8
        i32.and
        local.get 9
        i32.and
        local.get 10
        i32.and
        local.get 11
        i32.and
        local.get 12
        i32.and
        local.get 13
        i32.and
        i32.const 67108863
        i32.eq
        i32.or
        call $_RINvCsa76Hhft0kBi_6subtle9black_boxhECsaiz7UTicgxC_13crypto_bigint
        i32.const 255
        i32.and
        i32.const 0
        i32.ne
        local.set 3
        br 1 (;@1;)
      end
      local.get 5
      i32.const 0
      i32.ne
      local.set 3
    end
    local.get 2
    i64.const 160
    i64.add
    global.set $__stack_pointer
    local.get 3)
