  (func $_RNvXs2_NtNtCsfAt4k4enyRT_4k25610arithmetic6affineNtB5_11AffinePointNtCsa76Hhft0kBi_6subtle23ConditionallySelectable18conditional_select (type 10) (param i64 i64 i64 i32)
    (local i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32 i32)
    local.get 2
    i32.load
    local.set 4
    local.get 1
    i32.load
    local.set 5
    local.get 2
    i32.load offset=4
    local.set 6
    local.get 1
    i32.load offset=4
    local.set 7
    local.get 2
    i32.load offset=8
    local.set 8
    local.get 1
    i32.load offset=8
    local.set 9
    local.get 2
    i32.load offset=12
    local.set 10
    local.get 1
    i32.load offset=12
    local.set 11
    local.get 2
    i32.load offset=16
    local.set 12
    local.get 1
    i32.load offset=16
    local.set 13
    local.get 2
    i32.load offset=20
    local.set 14
    local.get 1
    i32.load offset=20
    local.set 15
    local.get 2
    i32.load offset=24
    local.set 16
    local.get 1
    i32.load offset=24
    local.set 17
    local.get 2
    i32.load offset=28
    local.set 18
    local.get 1
    i32.load offset=28
    local.set 19
    local.get 2
    i32.load offset=32
    local.set 20
    local.get 1
    i32.load offset=32
    local.set 21
    local.get 2
    i32.load offset=36
    local.set 22
    local.get 1
    i32.load offset=36
    local.set 23
    local.get 2
    i32.load offset=40
    local.set 24
    local.get 1
    i32.load offset=40
    local.set 25
    local.get 2
    i32.load offset=44
    local.set 26
    local.get 1
    i32.load offset=44
    local.set 27
    local.get 2
    i32.load offset=48
    local.set 28
    local.get 1
    i32.load offset=48
    local.set 29
    local.get 2
    i32.load offset=52
    local.set 30
    local.get 1
    i32.load offset=52
    local.set 31
    local.get 2
    i32.load offset=56
    local.set 32
    local.get 1
    i32.load offset=56
    local.set 33
    local.get 2
    i32.load offset=60
    local.set 34
    local.get 1
    i32.load offset=60
    local.set 35
    local.get 2
    i32.load offset=64
    local.set 36
    local.get 1
    i32.load offset=64
    local.set 37
    local.get 2
    i32.load offset=68
    local.set 38
    local.get 1
    i32.load offset=68
    local.set 39
    local.get 2
    i32.load offset=72
    local.set 40
    local.get 1
    i32.load offset=72
    local.set 41
    local.get 2
    i32.load offset=76
    local.set 42
    local.get 1
    i32.load offset=76
    local.set 43
    local.get 0
    local.get 2
    i32.load8_u offset=80
    local.get 1
    i32.load8_u offset=80
    local.tee 44
    i32.xor
    i32.const 0
    local.get 3
    i32.sub
    i32.and
    local.get 44
    i32.xor
    i32.store8 offset=80
    local.get 0
    local.get 43
    local.get 42
    local.get 43
    i32.xor
    i32.const 0
    local.get 3
    i32.const 255
    i32.and
    i32.sub
    local.tee 3
    i32.and
    i32.xor
    i32.store offset=76
    local.get 0
    local.get 41
    local.get 40
    local.get 41
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=72
    local.get 0
    local.get 39
    local.get 38
    local.get 39
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=68
    local.get 0
    local.get 37
    local.get 36
    local.get 37
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=64
    local.get 0
    local.get 35
    local.get 34
    local.get 35
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=60
    local.get 0
    local.get 33
    local.get 32
    local.get 33
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=56
    local.get 0
    local.get 31
    local.get 30
    local.get 31
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=52
    local.get 0
    local.get 29
    local.get 28
    local.get 29
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=48
    local.get 0
    local.get 27
    local.get 26
    local.get 27
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=44
    local.get 0
    local.get 25
    local.get 24
    local.get 25
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=40
    local.get 0
    local.get 23
    local.get 22
    local.get 23
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=36
    local.get 0
    local.get 21
    local.get 20
    local.get 21
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=32
    local.get 0
    local.get 19
    local.get 18
    local.get 19
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=28
    local.get 0
    local.get 17
    local.get 16
    local.get 17
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=24
    local.get 0
    local.get 15
    local.get 14
    local.get 15
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=20
    local.get 0
    local.get 13
    local.get 12
    local.get 13
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=16
    local.get 0
    local.get 11
    local.get 10
    local.get 11
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=12
    local.get 0
    local.get 9
    local.get 8
    local.get 9
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=8
    local.get 0
    local.get 7
    local.get 6
    local.get 7
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store offset=4
    local.get 0
    local.get 5
    local.get 4
    local.get 5
    i32.xor
    local.get 3
    i32.and
    i32.xor
    i32.store)
