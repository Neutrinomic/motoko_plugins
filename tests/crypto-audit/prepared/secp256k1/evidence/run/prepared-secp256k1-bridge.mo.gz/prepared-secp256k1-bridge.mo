//MOC-FLAG --package fast /srv/shared/code/motoko_experiments/plugins/_build/prepared-crypto/secp256k1/packages/fast/src --plugin /srv/shared/code/motoko_experiments/plugins/_build/prepared-crypto/secp256k1/dist/secp256k1 --sanity-checks
import Curve "mo:fast/Secp256k1";

func _preparedEcdsa(key : Blob, digest : Blob, signature : Blob) : Curve.Result<Bool> {
  switch (Curve.preparePublicKey(key)) {
    case (#err e) #err(e);
    case (#ok p) Curve.verifyPrehashPrepared(p, digest, signature);
  }
};
func _preparedSchnorr(key : Blob, message : Blob, signature : Blob) : Curve.Result<Bool> {
  switch (Curve.prepareSchnorrPublicKey(key)) {
    case (#err e) #err(e);
    case (#ok p) Curve.schnorrVerifyPrepared(p, message, signature);
  }
};
func _preparedSign(key : Blob, message : Blob, aux : Blob) : Curve.Result<Blob> {
  switch (Curve.prepareSchnorrSecretKey(key)) {
    case (#err e) #err(e);
    case (#ok p) Curve.schnorrSignPrepared(p, message, aux);
  }
};
func _expectErr<T>(result : Curve.Result<T>, expected : Curve.Error) {
  switch result { case (#ok _) assert false; case (#err error) assert error == expected }
};
func _ok<T>(result : Curve.Result<T>) : T {
  switch result { case (#ok value) value; case (#err _) { assert false; loop {} } }
};
let secret : Blob = "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\03";
let key : Blob = "\02\f9\30\8a\01\92\58\c3\10\49\34\4f\85\f8\9d\52\29\b5\31\c8\45\83\6f\99\b0\86\01\f1\13\bc\e0\36\f9";
let x : Blob = "\f9\30\8a\01\92\58\c3\10\49\34\4f\85\f8\9d\52\29\b5\31\c8\45\83\6f\99\b0\86\01\f1\13\bc\e0\36\f9";
let digest : Blob = "\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00";
let signature : Blob = "\e9\50\58\f4\83\25\b8\b3\74\15\ed\d8\98\82\2f\cf\c8\3d\8f\dc\5e\25\7d\3c\37\0c\03\04\c4\2d\d5\f2\68\36\45\0f\27\b3\cc\d9\d0\e8\66\29\62\7b\28\b6\1f\cd\ae\ab\49\d9\09\9f\41\70\cc\d3\b3\25\8e\81";
let schnorr : Blob = "\e9\07\83\1f\80\84\8d\10\69\a5\37\1b\40\24\10\36\4b\df\1c\5f\83\07\b0\08\4c\55\f1\ce\2d\ca\82\15\25\f6\6a\4a\85\ea\8b\71\e4\82\a7\4f\38\2d\2c\e5\eb\ee\e8\fd\b2\17\2f\47\7d\f4\90\0d\31\05\36\c0";

let ecdsa = _ok(Curve.preparePublicKey(key));
let publicSchnorr = _ok(Curve.prepareSchnorrPublicKey(x));
let signer = _ok(Curve.prepareSchnorrSecretKey(secret));
var sequence : Nat = 0;
func arg(n : Nat, value : Blob) : Blob { sequence := sequence*10+n; value };
func keyArg() : Curve.PreparedPublicKey { sequence := sequence*10+1; ecdsa };
func publicArg() : Curve.PreparedSchnorrPublicKey { sequence := sequence*10+1; publicSchnorr };
func secretArg() : Curve.PreparedSchnorrSecretKey { sequence := sequence*10+1; signer };
assert Curve.verifyPrehashPrepared(keyArg(),arg(2,digest),arg(3,signature)) == #ok(true);
assert sequence == 123;
sequence := 0;
assert Curve.verifyPrehashPrepared(keyArg(),arg(2,""),arg(3,"")) == #err(#invalidDigest);
assert sequence == 123;
sequence := 0;
assert Curve.verifyPrehashPrepared(keyArg(),arg(2,digest),arg(3,"")) == #err(#invalidSignature);
assert sequence == 123;
sequence := 0;
assert Curve.schnorrVerifyPrepared(publicArg(),arg(2,digest),arg(3,schnorr)) == #ok(true);
assert sequence == 123;
sequence := 0;
assert Curve.schnorrVerifyPrepared(publicArg(),arg(2,digest),arg(3,"")) == #err(#invalidSignature);
assert sequence == 123;
sequence := 0;
assert Curve.schnorrSignPrepared(secretArg(),arg(2,digest),arg(3,digest)) == #ok(schnorr);
assert sequence == 123;
sequence := 0;
assert Curve.schnorrSignPrepared(secretArg(),arg(2,digest),arg(3,"")) == #err(#invalidAuxiliaryRandomness);
assert sequence == 123;
let verify = Curve.verifyPrehashPrepared;
let publicVerify = Curve.schnorrVerifyPrepared;
let sign = Curve.schnorrSignPrepared;
let factories = [Curve.preparePublicKey, Curve.preparePublicKey];
assert verify(_ok(factories[1](key)),digest,signature) == #ok(true);
assert publicVerify(publicSchnorr,digest,schnorr) == #ok(true);
assert sign(signer,digest,digest) == #ok(schnorr);
// Earlier errors cannot change subsequent valid operations or any cached key.
assert Curve.verifyPrehashPrepared(ecdsa,digest,signature) == #ok(true);
assert Curve.schnorrSignPrepared(signer,digest,digest) == #ok(schnorr);
_expectErr(Curve.prepareSchnorrSecretKey(""), #invalidSecretKey);
_expectErr(Curve.prepareSchnorrSecretKey("\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00"), #invalidSecretKey);
_expectErr(Curve.prepareSchnorrSecretKey("\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00"), #invalidSecretKey);
_expectErr(Curve.prepareSchnorrSecretKey("\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00"), #invalidSecretKey);
_expectErr(Curve.prepareSchnorrSecretKey("\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\41"), #invalidSecretKey);
_expectErr(Curve.prepareSchnorrSecretKey("\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\42"), #invalidSecretKey);
_expectErr(Curve.prepareSchnorrSecretKey("\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff"), #invalidSecretKey);
_expectErr(Curve.preparePublicKey(""), #invalidPublicKey);
_expectErr(Curve.preparePublicKey("\00"), #invalidPublicKey);
_expectErr(Curve.preparePublicKey("\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00"), #invalidPublicKey);
_expectErr(Curve.preparePublicKey("\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00"), #invalidPublicKey);
_expectErr(Curve.preparePublicKey("\06\f9\30\8a\01\92\58\c3\10\49\34\4f\85\f8\9d\52\29\b5\31\c8\45\83\6f\99\b0\86\01\f1\13\bc\e0\36\f9\38\8f\7b\0f\63\2d\e8\14\0f\e3\37\e6\2a\37\f3\56\65\00\a9\99\34\c2\23\1b\6c\b9\fd\75\84\b8\e6\72"), #invalidPublicKey);
_expectErr(Curve.preparePublicKey("\02\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ff\ff\fc\2f"), #invalidPublicKey);
_expectErr(Curve.preparePublicKey("\02\f9\30\8a\01\92\58\c3\10\49\34\4f\85\f8\9d\52\29\b5\31\c8\45\83\6f\99\b0\86\01\f1\13\bc\e0\36\f9\00"), #invalidPublicKey);
_expectErr(Curve.preparePublicKey("\04\f9\30\8a\01\92\58\c3\10\49\34\4f\85\f8\9d\52\29\b5\31\c8\45\83\6f\99\b0\86\01\f1\13\bc\e0\36\f9\38\8f\7b\0f\63\2d\e8\14\0f\e3\37\e6\2a\37\f3\56\65\00\a9\99\34\c2\23\1b\6c\b9\fd\75\84\b8\e6\73"), #invalidPublicKey);
_expectErr(Curve.prepareSchnorrPublicKey(""), #invalidPublicKey);
_expectErr(Curve.prepareSchnorrPublicKey("\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00"), #invalidPublicKey);
_expectErr(Curve.prepareSchnorrPublicKey("\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00"), #invalidPublicKey);
_expectErr(Curve.prepareSchnorrPublicKey("\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00"), #invalidPublicKey);
_expectErr(Curve.prepareSchnorrPublicKey("\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ff\ff\fc\2f"), #invalidPublicKey);
_expectErr(Curve.prepareSchnorrPublicKey("\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff"), #invalidPublicKey);
assert Curve.verifyPrehashPrepared(ecdsa,digest,"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01") == #err(#invalidSignature);
assert Curve.verifyPrehashPrepared(ecdsa,digest,"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00") == #err(#invalidSignature);
assert Curve.verifyPrehashPrepared(ecdsa,digest,"\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\41\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01") == #err(#invalidSignature);
assert Curve.verifyPrehashPrepared(ecdsa,digest,"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\41") == #err(#invalidSignature);
assert Curve.verifyPrehashPrepared(ecdsa,digest,"\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\40\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\40") == Curve.verifyPrehash(key,digest,"\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\40\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\40");
assert Curve.schnorrVerifyPrepared(publicSchnorr,digest,"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00") == Curve.schnorrVerify(x,digest,"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00");
assert Curve.schnorrVerifyPrepared(publicSchnorr,digest,"\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ff\ff\fc\2f\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00") == #err(#invalidSignature);
assert Curve.schnorrVerifyPrepared(publicSchnorr,digest,"\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\41") == #err(#invalidSignature);
assert Curve.schnorrVerifyPrepared(publicSchnorr,digest,"\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ff\ff\fc\2e\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\40") == Curve.schnorrVerify(x,digest,"\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ff\ff\fc\2e\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\40");
