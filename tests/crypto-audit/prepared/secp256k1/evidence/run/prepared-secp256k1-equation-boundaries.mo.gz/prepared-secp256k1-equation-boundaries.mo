//MOC-FLAG --package fast /srv/shared/code/motoko_experiments/plugins/_build/prepared-crypto/secp256k1/packages/fast/src --plugin /srv/shared/code/motoko_experiments/plugins/_build/prepared-crypto/secp256k1/dist/secp256k1 --sanity-checks
import Curve "mo:fast/Secp256k1";

func _preparedEcdsa(key : Blob, digest : Blob, signature : Blob) : Curve.Result<Bool> {
  switch (Curve.preparePublicKey(key)) {
    case (#err e) #err(e);
    case (#ok p) Curve.verifyPrehashPrepared(p, digest, signature);
  }
};
func _preparedSchnorr(key : Blob, message : Blob, signature : Blob) : Curve.Result<Bool> {
  switch (Curve.prepareSchnorrPublicKey(key)) {
    case (#err e) #err(e);
    case (#ok p) Curve.schnorrVerifyPrepared(p, message, signature);
  }
};
func _preparedSign(key : Blob, message : Blob, aux : Blob) : Curve.Result<Blob> {
  switch (Curve.prepareSchnorrSecretKey(key)) {
    case (#err e) #err(e);
    case (#ok p) Curve.schnorrSignPrepared(p, message, aux);
  }
};
func _expectErr<T>(result : Curve.Result<T>, expected : Curve.Error) {
  switch result { case (#ok _) assert false; case (#err error) assert error == expected }
};
func _ok<T>(result : Curve.Result<T>) : T {
  switch result { case (#ok value) value; case (#err _) { assert false; loop {} } }
};

assert _preparedEcdsa("\02\79\be\66\7e\f9\dc\bb\ac\55\a0\62\95\ce\87\0b\07\02\9b\fc\db\2d\ce\28\d9\59\f2\81\5b\16\f8\17\98","\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\40","\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01") == #ok(false);
assert _preparedEcdsa("\02\79\be\66\7e\f9\dc\bb\ac\55\a0\62\95\ce\87\0b\07\02\9b\fc\db\2d\ce\28\d9\59\f2\81\5b\16\f8\17\98","\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\40","\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\40") == #ok(false);
assert _preparedEcdsa("\03\ad\80\2f\21\45\df\54\8c\e1\fc\41\8b\85\1c\b3\26\69\c5\a6\bb\93\9e\6c\af\74\4d\e9\03\10\f8\f1\ff","\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00","\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01") == #ok(true);
assert _preparedEcdsa("\03\ad\80\2f\21\45\df\54\8c\e1\fc\41\8b\85\1c\b3\26\69\c5\a6\bb\93\9e\6c\af\74\4d\e9\03\10\f8\f1\ff","\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00","\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\02\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\ff\fe\ba\ae\dc\e6\af\48\a0\3b\bf\d2\5e\8c\d0\36\41\40") == #ok(true);
